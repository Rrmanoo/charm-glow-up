import os
import math
import requests
from PIL import Image
from io import BytesIO
from typing import Tuple

class SatelliteImageService:
    """Service for fetching satellite imagery from Google Maps Static API"""

    # Hard-coded Google Maps API Key
    GOOGLE_MAPS_API_KEY = "YOUR_API_KEY_HERE"  # Replace with your actual API key

    def __init__(self):
        self.api_key = self.GOOGLE_MAPS_API_KEY
        self.base_url = "https://maps.googleapis.com/maps/api/staticmap"

    def calculate_zoom_level(self, hectares: float, image_size: int = 640) -> int:
        """
        Calculate appropriate zoom level for Google Maps based on field size

        Args:
            hectares: Field size in hectares
            image_size: Image size in pixels (default 640)

        Returns:
            Zoom level (1-20)
        """
        # Convert hectares to square meters
        area_m2 = hectares * 10000

        # Calculate approximate side length (assuming square field)
        side_length_m = math.sqrt(area_m2)

        # Google Maps zoom levels (approximate meters per pixel at equator)
        # Zoom 20: 1.19m/px, 19: 2.39m/px, 18: 4.78m/px, 17: 9.55m/px, 16: 19.11m/px, 15: 38.22m/px
        zoom_scales = {
            20: 1.19, 19: 2.39, 18: 4.78, 17: 9.55, 16: 19.11,
            15: 38.22, 14: 76.44, 13: 152.87, 12: 305.75, 11: 611.5
        }

        # Calculate required meters per pixel
        required_mpp = side_length_m / image_size

        # Find best zoom level
        best_zoom = 15  # Default
        for zoom, mpp in sorted(zoom_scales.items(), reverse=True):
            if mpp <= required_mpp * 1.2:  # Add 20% margin
                best_zoom = zoom
                break

        return best_zoom

    def calculate_field_bounds(self, center_lat: float, center_lon: float,
                               hectares: float) -> Tuple[float, float, float, float]:
        """
        Calculate field boundaries from center point and size

        Args:
            center_lat: Center latitude
            center_lon: Center longitude
            hectares: Field size in hectares

        Returns:
            Tuple of (min_lat, max_lat, min_lon, max_lon)
        """
        # Convert hectares to square meters
        area_m2 = hectares * 10000

        # Assume square field for simplicity
        side_length_m = math.sqrt(area_m2)
        half_side = side_length_m / 2

        # Approximate degrees per meter (at given latitude)
        lat_deg_per_m = 1 / 111320.0
        lon_deg_per_m = 1 / (111320.0 * math.cos(math.radians(center_lat)))

        # Calculate bounds
        min_lat = center_lat - (half_side * lat_deg_per_m)
        max_lat = center_lat + (half_side * lat_deg_per_m)
        min_lon = center_lon - (half_side * lon_deg_per_m)
        max_lon = center_lon + (half_side * lon_deg_per_m)

        return (min_lat, max_lat, min_lon, max_lon)

    def fetch_satellite_image(self, center_lat: float, center_lon: float,
                             hectares: float, image_size: int = 640) -> str:
        """
        Fetch satellite image from Google Maps Static API

        Args:
            center_lat: Center latitude
            center_lon: Center longitude
            hectares: Field size in hectares
            image_size: Desired image size (max 640 for free tier)

        Returns:
            Path to saved satellite image
        """
        if not self.api_key or self.api_key == "YOUR_API_KEY_HERE":
            print("Warning: Google Maps API key not configured. Using placeholder.")
            return None

        # Calculate optimal zoom level
        zoom = self.calculate_zoom_level(hectares, image_size)

        # Build API request
        params = {
            'center': f"{center_lat},{center_lon}",
            'zoom': zoom,
            'size': f"{image_size}x{image_size}",
            'maptype': 'satellite',
            'key': self.api_key
        }

        try:
            # Fetch image from Google Maps
            response = requests.get(self.base_url, params=params, timeout=10)
            response.raise_for_status()

            # Save image
            img = Image.open(BytesIO(response.content))

            # Ensure visualizations directory exists
            os.makedirs('visualizations/satellite_images', exist_ok=True)

            # Save with unique filename
            filename = f"satellite_{center_lat:.6f}_{center_lon:.6f}.png"
            filepath = os.path.join('visualizations/satellite_images', filename)
            img.save(filepath)

            print(f"Satellite image saved: {filepath}")
            return filepath

        except requests.RequestException as e:
            print(f"Error fetching satellite image: {e}")
            return None
        except Exception as e:
            print(f"Error processing satellite image: {e}")
            return None

    def create_placeholder_image(self, hectares: float, image_size: int = 640) -> str:
        """
        Create a placeholder satellite image when API is not available

        Args:
            hectares: Field size in hectares
            image_size: Image size in pixels

        Returns:
            Path to placeholder image
        """
        from PIL import ImageDraw, ImageFont

        # Create gray placeholder
        img = Image.new('RGB', (image_size, image_size), color='#d0d0d0')
        draw = ImageDraw.Draw(img)

        # Draw grid lines
        for i in range(0, image_size, image_size // 10):
            draw.line([(i, 0), (i, image_size)], fill='#a0a0a0', width=1)
            draw.line([(0, i), (image_size, i)], fill='#a0a0a0', width=1)

        # Add text
        text = f"Satellite Image\n{hectares} hectares\n(API Key Required)"

        try:
            # Try to use default font
            font = ImageFont.load_default()
        except:
            font = None

        # Calculate text position
        text_bbox = draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]

        x = (image_size - text_width) // 2
        y = (image_size - text_height) // 2

        draw.text((x, y), text, fill='#606060', font=font, align='center')

        # Save placeholder
        os.makedirs('visualizations/satellite_images', exist_ok=True)
        filepath = 'visualizations/satellite_images/placeholder.png'
        img.save(filepath)

        return filepath
