import os
from PIL import Image, ImageDraw, ImageFont
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from typing import Dict, List
import json
import base64
from io import BytesIO

class VisualizationService:
    """Service for generating field visualizations and dashboards"""
    
    def __init__(self):
        self.output_dir = "visualizations"
        os.makedirs(self.output_dir, exist_ok=True)
    
    def create_field_visualization(self, field_data: Dict, 
                                   analysis_data: Dict,
                                   satellite_image_path: str = None) -> str:
        """
        Create comprehensive field visualization with satellite overlay
        
        Args:
            field_data: Field information (name, zones, etc.)
            analysis_data: Analysis results with zone statistics
            satellite_image_path: Path to satellite image
        
        Returns:
            Path to generated visualization image
        """
        # Create figure with subplots
        fig = plt.figure(figsize=(16, 12))
        
        # Layout: Top: satellite + overlay, Bottom: analytics
        gs = fig.add_gridspec(2, 2, height_ratios=[2, 1], hspace=0.3, wspace=0.3)
        
        # 1. Satellite image with grid overlay
        ax_satellite = fig.add_subplot(gs[0, :])
        self._draw_satellite_overlay(ax_satellite, field_data, analysis_data, satellite_image_path)
        
        # 2. Zone heatmap
        ax_heatmap = fig.add_subplot(gs[1, 0])
        self._draw_zone_heatmap(ax_heatmap, analysis_data['zone_statistics'])
        
        # 3. Weed species distribution
        ax_species = fig.add_subplot(gs[1, 1])
        self._draw_species_distribution(ax_species, analysis_data['weed_species_distribution'])
        
        # Add title
        fig.suptitle(f"Field Analysis Report: {field_data['name']}", 
                    fontsize=20, fontweight='bold')
        
        # Save figure
        output_path = os.path.join(self.output_dir, f"field_{field_data['id']}_analysis.png")
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return output_path
    
    def _draw_satellite_overlay(self, ax, field_data, analysis_data, satellite_path):
        """Draw satellite image with zone grid overlay"""
        if satellite_path and os.path.exists(satellite_path):
            img = Image.open(satellite_path)
            ax.imshow(img)
        else:
            # Create placeholder if no satellite image
            ax.set_xlim(0, 640)
            ax.set_ylim(0, 640)
            ax.set_facecolor('#e0e0e0')
            ax.text(320, 320, 'Satellite Image\n(Not Available)', 
                   ha='center', va='center', fontsize=16, color='gray')
        
        # Draw 3x3 grid overlay
        width = 640
        height = 640
        cell_width = width / 3
        cell_height = height / 3
        
        zone_stats = {z['zone']: z for z in analysis_data['zone_statistics']}
        
        for zone_num in range(1, 10):
            row = (zone_num - 1) // 3
            col = (zone_num - 1) % 3
            
            x = col * cell_width
            y = row * cell_height
            
            # Get infestation level
            level = zone_stats[zone_num]['infestation_level']
            
            # Color code by infestation
            if level == 'high':
                color = 'red'
                alpha = 0.4
            elif level == 'medium':
                color = 'orange'
                alpha = 0.3
            elif level == 'low':
                color = 'green'
                alpha = 0.2
            else:
                color = 'gray'
                alpha = 0.1
            
            # Draw zone rectangle
            rect = mpatches.Rectangle((x, y), cell_width, cell_height,
                                     linewidth=2, edgecolor='white',
                                     facecolor=color, alpha=alpha)
            ax.add_patch(rect)
            
            # Add zone label
            zone_name = zone_stats[zone_num]['zone_name']
            weed_count = zone_stats[zone_num]['weeds_detected']
            
            ax.text(x + cell_width/2, y + cell_height/2,
                   f"Zone {zone_num}\n{zone_name}\n{weed_count} weeds",
                   ha='center', va='center',
                   fontsize=10, fontweight='bold',
                   color='white',
                   bbox=dict(boxstyle='round', facecolor='black', alpha=0.7))
        
        ax.set_title('Field Map with Weed Distribution', fontsize=14, fontweight='bold')
        ax.axis('off')
    
    def _draw_zone_heatmap(self, ax, zone_statistics):
        """Draw heatmap showing area-based infestation percentage per zone"""
        # Prepare data for 3x3 grid
        grid_data = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]

        for zone_stat in zone_statistics:
            zone = zone_stat['zone']
            row = (zone - 1) // 3
            col = (zone - 1) % 3
            # Use infestation_percentage if available, otherwise fall back to weed_density
            grid_data[row][col] = zone_stat.get('infestation_percentage', zone_stat.get('weed_density', 0))

        # Create heatmap with appropriate scale for percentages (0-100)
        im = ax.imshow(grid_data, cmap='YlOrRd', aspect='auto', vmin=0, vmax=100)

        # Add colorbar
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Infestation % (Area Coverage)', rotation=270, labelpad=20)

        # Add zone labels and values
        for i in range(3):
            for j in range(3):
                zone_num = i * 3 + j + 1
                text = ax.text(j, i, f"Zone {zone_num}\n{grid_data[i][j]:.1f}%",
                             ha="center", va="center", color="black", fontweight='bold')

        ax.set_xticks([0, 1, 2])
        ax.set_yticks([0, 1, 2])
        ax.set_xticklabels(['Left', 'Center', 'Right'])
        ax.set_yticklabels(['Top', 'Middle', 'Bottom'])
        ax.set_title('Infestation Heatmap (Area-Based)', fontsize=12, fontweight='bold')
    
    def _draw_species_distribution(self, ax, weed_species_dist):
        """Draw pie chart of weed species distribution"""
        if not weed_species_dist:
            ax.text(0.5, 0.5, 'No weed species detected',
                   ha='center', va='center', transform=ax.transAxes)
            ax.axis('off')
            return
        
        # Sort by count
        sorted_species = sorted(weed_species_dist.items(), 
                              key=lambda x: x[1], reverse=True)
        
        # Take top 8 species, group rest as "Others"
        if len(sorted_species) > 8:
            top_species = sorted_species[:8]
            others_count = sum(count for _, count in sorted_species[8:])
            top_species.append(('Others', others_count))
        else:
            top_species = sorted_species
        
        labels = [s[0].replace('weed:', '') for s in top_species]
        sizes = [s[1] for s in top_species]
        
        # Create pie chart
        colors = plt.cm.Set3(range(len(labels)))
        wedges, texts, autotexts = ax.pie(sizes, labels=labels, colors=colors,
                                          autopct='%1.1f%%', startangle=90)
        
        # Improve text readability
        for text in texts:
            text.set_fontsize(9)
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontweight('bold')
            autotext.set_fontsize(9)
        
        ax.set_title('Weed Species Distribution', fontsize=12, fontweight='bold')
    
    def generate_html_dashboard(self, field_data: Dict, 
                               analysis_data: Dict,
                               visualization_path: str) -> str:
        """Generate interactive HTML dashboard"""
        
        # Convert visualization to base64
        with open(visualization_path, 'rb') as img_file:
            img_base64 = base64.b64encode(img_file.read()).decode()
        
        # Prepare data
        total_images = analysis_data['total_images_processed']
        total_weeds = analysis_data['total_weeds_detected']
        total_crops = analysis_data['total_crops_detected']

        # Use overall infestation percentage if available (average of all zones)
        weed_percentage = analysis_data.get('overall_infestation_percentage', 0)

        # Fallback calculation if not available
        if weed_percentage == 0:
            zone_stats = analysis_data.get('zone_statistics', [])
            if zone_stats:
                weed_percentage = sum(z.get('infestation_percentage', 0) for z in zone_stats) / len(zone_stats)
            elif total_crops + total_weeds > 0:
                weed_percentage = (total_weeds / (total_weeds + total_crops)) * 100
        
        hotspot_zones = analysis_data.get('hotspot_zones', [])
        treatment_priority = analysis_data.get('treatment_priority', [])
        
        # Generate HTML
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Field Analysis Dashboard - {field_data['name']}</title>
            <style>
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 20px;
                    color: #333;
                }}
                .container {{
                    max-width: 1400px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                    overflow: hidden;
                }}
                .header {{
                    background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
                    color: white;
                    padding: 30px;
                    text-align: center;
                }}
                .header h1 {{
                    font-size: 2.5em;
                    margin-bottom: 10px;
                }}
                .header p {{
                    font-size: 1.2em;
                    opacity: 0.9;
                }}
                .stats-grid {{
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 20px;
                    padding: 30px;
                    background: #f5f5f5;
                }}
                .stat-card {{
                    background: white;
                    padding: 25px;
                    border-radius: 10px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    text-align: center;
                    transition: transform 0.3s;
                }}
                .stat-card:hover {{
                    transform: translateY(-5px);
                    box-shadow: 0 8px 12px rgba(0,0,0,0.15);
                }}
                .stat-card .value {{
                    font-size: 3em;
                    font-weight: bold;
                    color: #2e7d32;
                    margin: 10px 0;
                }}
                .stat-card .label {{
                    font-size: 1.1em;
                    color: #666;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                }}
                .visualization {{
                    padding: 30px;
                }}
                .visualization img {{
                    width: 100%;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                }}
                .recommendations {{
                    padding: 30px;
                    background: #fff3cd;
                }}
                .recommendations h2 {{
                    color: #856404;
                    margin-bottom: 20px;
                }}
                .recommendation-item {{
                    background: white;
                    padding: 15px;
                    margin-bottom: 15px;
                    border-left: 4px solid #ffc107;
                    border-radius: 5px;
                }}
                .recommendation-item h3 {{
                    color: #2e7d32;
                    margin-bottom: 10px;
                }}
                .hotspot-badge {{
                    display: inline-block;
                    background: #d32f2f;
                    color: white;
                    padding: 5px 10px;
                    border-radius: 20px;
                    font-size: 0.9em;
                    margin: 5px;
                }}
                .footer {{
                    text-align: center;
                    padding: 20px;
                    background: #f5f5f5;
                    color: #666;
                }}
                .button {{
                    display: inline-block;
                    background: #4caf50;
                    color: white;
                    padding: 12px 30px;
                    border-radius: 25px;
                    text-decoration: none;
                    margin: 20px;
                    font-weight: bold;
                    transition: background 0.3s;
                }}
                .button:hover {{
                    background: #388e3c;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🌾 Field Analysis Dashboard</h1>
                    <p>{field_data['name']} | {field_data.get('location_name', 'Kazakhstan')}</p>
                    <p style="font-size: 0.9em; margin-top: 10px;">
                        {field_data['size_hectares']} hectares | Analysis Date: {analysis_data.get('analysis_date', 'Today')}
                    </p>
                </div>
                
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="label">Images Processed</div>
                        <div class="value">{total_images}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Total Weeds</div>
                        <div class="value" style="color: #d32f2f;">{total_weeds}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Total Crops</div>
                        <div class="value" style="color: #388e3c;">{total_crops}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Weed Infestation (Area-Based)</div>
                        <div class="value" style="color: #f57c00;">{weed_percentage:.1f}%</div>
                    </div>
                </div>
                
                <div class="visualization">
                    <h2 style="margin-bottom: 20px; color: #2e7d32;">📊 Field Visualization</h2>
                    <img src="data:image/png;base64,{img_base64}" alt="Field Analysis Visualization">
                </div>
                
                <div class="recommendations">
                    <h2>⚠️ Treatment Recommendations</h2>
                    
                    <div class="recommendation-item">
                        <h3>🎯 Priority Zones (Hotspots)</h3>
                        <p>The following zones require immediate attention:</p>
                        <div>
                            {''.join([f'<span class="hotspot-badge">Zone {z}</span>' for z in hotspot_zones]) if hotspot_zones else '<p>No critical hotspots detected</p>'}
                        </div>
                    </div>
                    
                    {''.join([f'''
                    <div class="recommendation-item">
                        <h3>Priority {rec['priority']}: {rec['action']}</h3>
                        <p>{rec['description']}</p>
                    </div>
                    ''' for rec in treatment_priority])}
                </div>
                
                <div class="footer">
                    <a href="/" class="button">← Back to Dashboard</a>
                    <a href="/fields/{field_data['id']}/export-report" class="button">📄 Download PDF Report</a>
                    <p style="margin-top: 20px;">
                        Generated by Weed Detection System | Master's Dissertation Project
                    </p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Save HTML file
        html_path = os.path.join(self.output_dir, f"field_{field_data['id']}_dashboard.html")
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        return html_path