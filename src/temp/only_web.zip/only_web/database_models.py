from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, JSON, ForeignKey, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os

Base = declarative_base()

# Database connection - will be set from environment variable
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://weeduser:weedpass123@localhost:5432/weed_detection_db")

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Field(Base):
    """Agricultural field information"""
    __tablename__ = "fields"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    location_name = Column(String)  # e.g., "Akmola Region, Kazakhstan"
    center_lat = Column(Float, nullable=False)
    center_lon = Column(Float, nullable=False)
    size_hectares = Column(Float, nullable=False)
    
    # Field boundaries (optional - can calculate from center + size)
    boundary_coords = Column(JSON)  # [[lat1, lon1], [lat2, lon2], ...]
    
    # Grid zone information
    grid_zones = Column(JSON)  # Store 9 zone boundaries
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_processed = Column(Boolean, default=False)
    
    # Relationships
    images = relationship("FieldImage", back_populates="field", cascade="all, delete-orphan")
    analysis_results = relationship("FieldAnalysis", back_populates="field", cascade="all, delete-orphan")

class FieldImage(Base):
    """Images uploaded for specific field zones and blocks"""
    __tablename__ = "field_images"

    id = Column(Integer, primary_key=True, index=True)
    field_id = Column(Integer, ForeignKey("fields.id"), nullable=False)
    zone_number = Column(Integer, nullable=False)  # 1-9
    block_number = Column(Integer, nullable=False)  # 1-9 (block within zone)

    # Image information
    image_path = Column(String, nullable=False)
    original_filename = Column(String)
    
    # Optional GPS data (if images have EXIF)
    gps_lat = Column(Float, nullable=True)
    gps_lon = Column(Float, nullable=True)
    
    # Upload metadata
    upload_timestamp = Column(DateTime, default=datetime.utcnow)
    file_size_bytes = Column(Integer)
    
    # Processing status
    is_processed = Column(Boolean, default=False)
    
    # Relationships
    field = relationship("Field", back_populates="images")
    detections = relationship("DetectionResult", back_populates="image", cascade="all, delete-orphan")

class DetectionResult(Base):
    """YOLO detection results for each image"""
    __tablename__ = "detection_results"
    
    id = Column(Integer, primary_key=True, index=True)
    field_image_id = Column(Integer, ForeignKey("field_images.id"), nullable=False)
    
    # Detection counts
    weed_count = Column(Integer, default=0)
    crop_count = Column(Integer, default=0)
    total_detections = Column(Integer, default=0)
    
    # Weed types detected (e.g., {"weed:thistle": 3, "weed:dandelion": 5})
    weed_types_count = Column(JSON)
    
    # Full YOLO output (bounding boxes, confidence scores, etc.)
    detection_data = Column(JSON)
    
    # Area-based infestation metrics
    infestation_percentage = Column(Float, default=0.0)  # Area-based percentage

    # Processing metadata
    confidence_threshold = Column(Float, default=0.25)
    processed_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    image = relationship("FieldImage", back_populates="detections")

class FieldAnalysis(Base):
    """Aggregated analysis results for entire field"""
    __tablename__ = "field_analysis"
    
    id = Column(Integer, primary_key=True, index=True)
    field_id = Column(Integer, ForeignKey("fields.id"), nullable=False)
    
    # Overall statistics
    total_images_processed = Column(Integer)
    total_weeds_detected = Column(Integer)
    total_crops_detected = Column(Integer)

    # Overall field infestation percentage (average of all zone percentages)
    overall_infestation_percentage = Column(Float, default=0.0)

    # Zone-wise statistics (JSON array of 9 zones)
    zone_statistics = Column(JSON)
    # Example: [
    #   {"zone": 1, "images": 36, "weeds": 234, "crops": 456, "infestation_level": "high",
    #    "blocks": [...block stats...]},
    #   ...
    # ]

    # Block-wise statistics (JSON array of 81 blocks: 9 zones × 9 blocks)
    block_statistics = Column(JSON)
    # Example: [
    #   {"zone": 1, "block": 1, "images": 4, "weeds": 12, "crops": 20, "infestation_level": "medium"},
    #   ...
    # ]

    # Image-wise statistics (JSON array of 324 images with individual analytics)
    image_statistics = Column(JSON)
    # Example: [
    #   {"image_id": 1, "zone": 1, "block": 1, "filename": "img.jpg",
    #    "weeds": 3, "crops": 5, "weed_types": {...}, "dominant_weed": "thistle"},
    #   ...
    # ]
    
    # Weed distribution across entire field
    weed_species_distribution = Column(JSON)
    # Example: {"weed:thistle": 156, "weed:dandelion": 89, ...}
    
    # Satellite image path
    satellite_image_path = Column(String, nullable=True)
    visualization_image_path = Column(String, nullable=True)
    
    # Recommendations
    hotspot_zones = Column(JSON)  # List of zone numbers with high infestation
    treatment_priority = Column(JSON)  # Recommended treatment order
    
    # Metadata
    analysis_date = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    field = relationship("Field", back_populates="analysis_results")

# Create all tables
def init_database():
    Base.metadata.create_all(bind=engine)
    print("Database tables created successfully!")

def get_db():
    """Dependency for FastAPI endpoints"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

if __name__ == "__main__":
    init_database()