import os
import math
import zipfile
import shutil
from typing import List, Dict, Tuple
from sqlalchemy.orm import Session
from database_models import Field, FieldImage, DetectionResult, FieldAnalysis
from datetime import datetime
import json
from satellite_service import SatelliteImageService

class FieldManagementService:
    """Service for managing agricultural fields with zones and blocks"""

    def __init__(self, satellite_api_key: str = None):
        self.satellite_api_key = satellite_api_key
        self.images_base_path = "field_images"
        os.makedirs(self.images_base_path, exist_ok=True)

        # Initialize satellite service
        self.satellite_service = SatelliteImageService()

        # New requirements: 324 images total
        # 9 zones × 9 blocks × 4 images = 324 images
        self.IMAGES_PER_BLOCK = 4
        self.BLOCKS_PER_ZONE = 9
        self.ZONES_PER_FIELD = 9
        self.IMAGES_PER_ZONE = self.IMAGES_PER_BLOCK * self.BLOCKS_PER_ZONE  # 36
        self.TOTAL_IMAGES = self.IMAGES_PER_ZONE * self.ZONES_PER_FIELD  # 324

    def create_field(self, db: Session, name: str, center_lat: float,
                     center_lon: float, size_hectares: float,
                     location_name: str = None) -> Field:
        """
        Create a new field with 9 zones, each divided into 9 blocks

        Total structure:
        - 9 zones (3x3 grid)
        - Each zone has 9 blocks (3x3 grid)
        - Each block requires 4 images
        - Total: 324 images
        """
        # Calculate approximate field dimensions
        meters_per_degree_lat = 111320
        meters_per_degree_lon = 111320 * math.cos(math.radians(center_lat))

        side_length_meters = math.sqrt(size_hectares * 10000)

        lat_delta = side_length_meters / meters_per_degree_lat
        lon_delta = side_length_meters / meters_per_degree_lon

        # Calculate field boundaries
        boundary_coords = [
            [center_lat + lat_delta/2, center_lon - lon_delta/2],
            [center_lat + lat_delta/2, center_lon + lon_delta/2],
            [center_lat - lat_delta/2, center_lon + lon_delta/2],
            [center_lat - lat_delta/2, center_lon - lon_delta/2],
        ]

        # Calculate 9 zones with 9 blocks each
        grid_zones = self._calculate_grid_zones_with_blocks(
            center_lat, center_lon, lat_delta, lon_delta
        )

        field = Field(
            name=name,
            location_name=location_name,
            center_lat=center_lat,
            center_lon=center_lon,
            size_hectares=size_hectares,
            boundary_coords=boundary_coords,
            grid_zones=grid_zones
        )

        db.add(field)
        db.commit()
        db.refresh(field)

        # Fetch satellite image for the field
        satellite_path = self.fetch_satellite_image_for_field(field)
        if satellite_path:
            print(f"Satellite image fetched for field {field.id}: {satellite_path}")

        return field

    def fetch_satellite_image_for_field(self, field: Field) -> str:
        """
        Fetch satellite image for a field based on its coordinates and size

        Args:
            field: Field object with center coordinates and size

        Returns:
            Path to satellite image or None
        """
        try:
            # Try to fetch real satellite image
            satellite_path = self.satellite_service.fetch_satellite_image(
                center_lat=field.center_lat,
                center_lon=field.center_lon,
                hectares=field.size_hectares,
                image_size=640
            )

            # If API key not configured, create placeholder
            if not satellite_path:
                satellite_path = self.satellite_service.create_placeholder_image(
                    hectares=field.size_hectares,
                    image_size=640
                )

            return satellite_path

        except Exception as e:
            print(f"Error fetching satellite image: {e}")
            return None

    def _calculate_grid_zones_with_blocks(self, center_lat: float, center_lon: float,
                                          lat_delta: float, lon_delta: float) -> Dict:
        """Calculate 9 zones, each with 9 blocks (81 blocks total)"""
        zones = {}
        zone_mapping = {
            1: (0, 0), 2: (0, 1), 3: (0, 2),
            4: (1, 0), 5: (1, 1), 6: (1, 2),
            7: (2, 0), 8: (2, 1), 9: (2, 2)
        }

        for zone_num, (zone_row, zone_col) in zone_mapping.items():
            # Calculate zone boundaries
            zone_lat_start = center_lat + lat_delta/2 - (zone_row * lat_delta/3) - lat_delta/6
            zone_lat_end = zone_lat_start - lat_delta/3
            zone_lon_start = center_lon - lon_delta/2 + (zone_col * lon_delta/3)
            zone_lon_end = zone_lon_start + lon_delta/3

            zone_lat_delta = zone_lat_start - zone_lat_end
            zone_lon_delta = zone_lon_end - zone_lon_start

            # Calculate 9 blocks within this zone
            blocks = self._calculate_blocks_in_zone(
                zone_num, zone_lat_start, zone_lon_start, zone_lat_delta, zone_lon_delta
            )

            zones[zone_num] = {
                "zone_number": zone_num,
                "name": self._get_zone_name(zone_num),
                "bounds": {
                    "north": zone_lat_start,
                    "south": zone_lat_end,
                    "west": zone_lon_start,
                    "east": zone_lon_end
                },
                "center": {
                    "lat": (zone_lat_start + zone_lat_end) / 2,
                    "lon": (zone_lon_start + zone_lon_end) / 2
                },
                "blocks": blocks
            }

        return zones

    def _calculate_blocks_in_zone(self, zone_num: int, zone_lat_start: float,
                                   zone_lon_start: float, lat_delta: float,
                                   lon_delta: float) -> Dict:
        """Calculate 9 blocks (3x3 grid) within a zone"""
        blocks = {}
        block_mapping = {
            1: (0, 0), 2: (0, 1), 3: (0, 2),
            4: (1, 0), 5: (1, 1), 6: (1, 2),
            7: (2, 0), 8: (2, 1), 9: (2, 2)
        }

        for block_num, (block_row, block_col) in block_mapping.items():
            # Calculate block boundaries within zone
            block_lat_start = zone_lat_start - (block_row * lat_delta/3)
            block_lat_end = block_lat_start - lat_delta/3
            block_lon_start = zone_lon_start + (block_col * lon_delta/3)
            block_lon_end = block_lon_start + lon_delta/3

            blocks[block_num] = {
                "block_number": block_num,
                "name": self._get_block_name(zone_num, block_num),
                "bounds": {
                    "north": block_lat_start,
                    "south": block_lat_end,
                    "west": block_lon_start,
                    "east": block_lon_end
                },
                "center": {
                    "lat": (block_lat_start + block_lat_end) / 2,
                    "lon": (block_lon_start + block_lon_end) / 2
                }
            }

        return blocks

    def _get_zone_name(self, zone_num: int) -> str:
        """Get human-readable zone name"""
        zone_names = {
            1: "Top-Left", 2: "Top-Center", 3: "Top-Right",
            4: "Middle-Left", 5: "Middle-Center", 6: "Middle-Right",
            7: "Bottom-Left", 8: "Bottom-Center", 9: "Bottom-Right"
        }
        return zone_names.get(zone_num, f"Zone {zone_num}")

    def _get_block_name(self, zone_num: int, block_num: int) -> str:
        """Get human-readable block name"""
        block_positions = {
            1: "TL", 2: "TC", 3: "TR",
            4: "ML", 5: "MC", 6: "MR",
            7: "BL", 8: "BC", 9: "BR"
        }
        return f"Z{zone_num}-B{block_num} ({block_positions[block_num]})"

    def process_folder_upload(self, db: Session, field_id: int, zip_file_path: str) -> Dict:
        """
        Process a zip file containing folder structure:
        main_folder/
          zone_1/
            block_1/
              image1.jpg
              image2.jpg
              image3.jpg
              image4.jpg
            block_2/
              ...
            ... (9 blocks)
          zone_2/
            ...
          ... (9 zones)

        Returns statistics about upload
        """
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise ValueError(f"Field {field_id} not found")

        # Extract zip file
        extract_path = os.path.join(self.images_base_path, "temp_extract", str(field_id))
        os.makedirs(extract_path, exist_ok=True)

        with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)

        # Process folder structure
        stats = {
            "total_images": 0,
            "zones_found": 0,
            "blocks_found": 0,
            "errors": []
        }

        # Find main folder (ignore hidden folders and __MACOSX)
        root_folders = [f for f in os.listdir(extract_path)
                       if os.path.isdir(os.path.join(extract_path, f))
                       and not f.startswith('.')
                       and f.lower() != '__macosx']

        # If we still have multiple folders, try to find one with zone folders
        if len(root_folders) > 1:
            # Look for the folder that contains zone_X folders
            main_folder = None
            for folder in root_folders:
                folder_path = os.path.join(extract_path, folder)
                contents = os.listdir(folder_path)
                # Check if this folder has zone_X folders
                zone_folders = [f for f in contents if 'zone' in f.lower() or any(c.isdigit() for c in f)]
                if zone_folders:
                    main_folder = folder_path
                    break

            if not main_folder:
                raise ValueError(f"Expected 1 main folder with zone folders, found {len(root_folders)} folders: {root_folders}")
        elif len(root_folders) == 0:
            raise ValueError("No valid folder found in ZIP file")
        else:
            main_folder = os.path.join(extract_path, root_folders[0])

        # Process each zone folder
        for zone_folder_name in os.listdir(main_folder):
            zone_path = os.path.join(main_folder, zone_folder_name)
            # Skip if not a directory or is hidden/system folder
            if (not os.path.isdir(zone_path) or
                zone_folder_name.startswith('.') or
                zone_folder_name.lower() == '__macosx'):
                continue

            # Extract zone number from folder name (e.g., "zone_1" or "1")
            try:
                zone_num = int(''.join(filter(str.isdigit, zone_folder_name)))
                if zone_num < 1 or zone_num > 9:
                    stats["errors"].append(f"Invalid zone number: {zone_num}")
                    continue
                stats["zones_found"] += 1
            except ValueError:
                stats["errors"].append(f"Could not parse zone number from: {zone_folder_name}")
                continue

            # Process each block folder within zone
            for block_folder_name in os.listdir(zone_path):
                block_path = os.path.join(zone_path, block_folder_name)
                # Skip if not a directory or is hidden/system folder
                if (not os.path.isdir(block_path) or
                    block_folder_name.startswith('.') or
                    block_folder_name.lower() == '__macosx'):
                    continue

                # Extract block number
                try:
                    block_num = int(''.join(filter(str.isdigit, block_folder_name)))
                    if block_num < 1 or block_num > 9:
                        stats["errors"].append(f"Invalid block number: {block_num} in zone {zone_num}")
                        continue
                    stats["blocks_found"] += 1
                except ValueError:
                    stats["errors"].append(f"Could not parse block number from: {block_folder_name}")
                    continue

                # Process images in block (filter out hidden files and system files)
                image_files = [f for f in os.listdir(block_path)
                              if f.lower().endswith(('.jpg', '.jpeg', '.png'))
                              and not f.startswith('.')
                              and f.lower() != '.ds_store']

                for image_file in image_files:
                    src_path = os.path.join(block_path, image_file)

                    # Save image to proper location
                    field_image = self.save_field_image_from_file(
                        db=db,
                        field_id=field_id,
                        zone_number=zone_num,
                        block_number=block_num,
                        file_path=src_path,
                        original_filename=image_file
                    )

                    if field_image:
                        stats["total_images"] += 1

        # Cleanup temp files
        shutil.rmtree(extract_path)

        return stats

    def save_field_image_from_file(self, db: Session, field_id: int, zone_number: int,
                                    block_number: int, file_path: str,
                                    original_filename: str) -> FieldImage:
        """Save an image file to the database"""
        # Create directory structure: field_images/{field_id}/zone_{zone}/block_{block}/
        target_dir = os.path.join(
            self.images_base_path,
            str(field_id),
            f"zone_{zone_number}",
            f"block_{block_number}"
        )
        os.makedirs(target_dir, exist_ok=True)

        # Generate unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        file_extension = os.path.splitext(original_filename)[1]
        filename = f"z{zone_number}_b{block_number}_{timestamp}{file_extension}"
        target_path = os.path.join(target_dir, filename)

        # Copy file
        shutil.copy2(file_path, target_path)
        file_size = os.path.getsize(target_path)

        # Create database record
        field_image = FieldImage(
            field_id=field_id,
            zone_number=zone_number,
            block_number=block_number,
            image_path=target_path,
            original_filename=original_filename,
            file_size_bytes=file_size
        )

        db.add(field_image)
        db.commit()
        db.refresh(field_image)

        return field_image

    def get_field_statistics(self, db: Session, field_id: int) -> Dict:
        """Get detailed upload statistics for a field with block-level info"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            return None

        zone_stats = []
        total_images = 0

        for zone_num in range(1, 10):
            block_stats = []
            zone_images = 0

            for block_num in range(1, 10):
                count = db.query(FieldImage).filter(
                    FieldImage.field_id == field_id,
                    FieldImage.zone_number == zone_num,
                    FieldImage.block_number == block_num
                ).count()

                block_stats.append({
                    "block": block_num,
                    "block_name": self._get_block_name(zone_num, block_num),
                    "images_uploaded": count,
                    "required_images": self.IMAGES_PER_BLOCK,
                    "percentage": (count / self.IMAGES_PER_BLOCK) * 100,
                    "status": "complete" if count >= self.IMAGES_PER_BLOCK else "incomplete"
                })

                zone_images += count

            zone_stats.append({
                "zone": zone_num,
                "zone_name": self._get_zone_name(zone_num),
                "images_uploaded": zone_images,
                "required_images": self.IMAGES_PER_ZONE,
                "percentage": (zone_images / self.IMAGES_PER_ZONE) * 100,
                "blocks": block_stats
            })

            total_images += zone_images

        return {
            "field_id": field_id,
            "field_name": field.name,
            "total_images": total_images,
            "required_total": self.TOTAL_IMAGES,
            "completion_percentage": (total_images / self.TOTAL_IMAGES) * 100,
            "zones": zone_stats,
            "is_ready_for_processing": total_images >= self.TOTAL_IMAGES
        }
