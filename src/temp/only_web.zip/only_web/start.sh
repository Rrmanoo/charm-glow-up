#!/bin/bash

# Weed Detection & Field Mapping System - Startup Script
# This script starts the Docker-based system

set -e

echo "=================================="
echo "Weed Detection System - Starting"
echo "=================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Error: Docker is not installed"
    echo "Please install Docker first: https://docs.docker.com/get-docker/"
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Error: Docker Compose is not installed"
    echo "Please install Docker Compose first: https://docs.docker.com/compose/install/"
    exit 1
fi

# Check if model file exists
if [ ! -f "weed_classification_final_model.pt" ]; then
    echo "⚠️  Warning: Model file 'weed_classification_final_model.pt' not found"
    echo "The system will start but detection will not work without the model."
    echo "Press Ctrl+C to cancel or wait 5 seconds to continue..."
    sleep 5
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p field_images
mkdir -p visualizations

# Start Docker Compose
echo "🚀 Starting Docker containers..."
docker-compose up -d

# Wait for services to be ready
echo "⏳ Waiting for services to start..."
sleep 5

# Check if services are running
echo ""
echo "📊 Service Status:"
docker-compose ps

echo ""
echo "=================================="
echo "✅ System Started Successfully!"
echo "=================================="
echo ""
echo "Access the application at:"
echo "  🌐 Main Page:          http://localhost:8000"
echo "  🗺️  Field Management:   http://localhost:8000/fields"
echo "  📚 API Documentation:  http://localhost:8000/docs"
echo ""
echo "Useful commands:"
echo "  View logs:    docker-compose logs -f"
echo "  Stop system:  docker-compose stop"
echo "  Restart:      docker-compose restart"
echo "  Stop & clean: docker-compose down"
echo ""
echo "For full documentation, see: README_DEPLOYMENT.md"
echo "=================================="
