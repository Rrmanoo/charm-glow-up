import os
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from database_models import Field, FieldImage, DetectionResult, FieldAnalysis
from satellite_service import SatelliteImageService
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import torch

class BatchProcessingService:
    """Service for batch processing field images and generating analytics"""

    def __init__(self, weed_service: Any):
        """
        Initialize batch processing service

        Args:
            weed_service: WeedDetectionService instance with predict_image method
        """
        self.weed_service = weed_service
        self.satellite_service = SatelliteImageService()
    
    def process_field_images(self, db: Session, field_id: int, 
                            confidence_threshold: float = 0.25) -> FieldAnalysis:
        """
        Process all images for a field and generate comprehensive analysis
        
        Args:
            db: Database session
            field_id: Field ID to process
            confidence_threshold: YOLO confidence threshold
        
        Returns:
            FieldAnalysis object with results
        """
        # Get field and all its images
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise ValueError(f"Field {field_id} not found")
        
        images = db.query(FieldImage).filter(
            FieldImage.field_id == field_id,
            FieldImage.is_processed == False
        ).all()
        
        if not images:
            raise ValueError("No unprocessed images found for this field")
        
        print(f"Processing {len(images)} images for field: {field.name}")

        # Process images in batches using parallel processing
        zone_results = {i: {j: [] for j in range(1, 10)} for i in range(1, 10)}
        all_weed_types = {}
        total_weeds = 0
        total_crops = 0
        image_analytics = []

        # Process images in parallel batches
        results = self._process_images_parallel(images, confidence_threshold)

        # Aggregate results
        for image, result in zip(images, results):
            if result and result['success']:
                weed_types_in_image = self._count_weed_types(result['predictions'])
                infestation_pct = result['summary'].get('infestation_percentage', 0.0)

                # Save detection result
                detection = DetectionResult(
                    field_image_id=image.id,
                    weed_count=result['summary']['weed_count'],
                    crop_count=result['summary']['crop_count'],
                    total_detections=result['summary']['total_detections'],
                    weed_types_count=weed_types_in_image,
                    detection_data=result['predictions'],
                    confidence_threshold=confidence_threshold,
                    infestation_percentage=infestation_pct
                )
                db.add(detection)

                # Aggregate by zone and block
                zone_results[image.zone_number][image.block_number].append(detection)

                # Update totals
                total_weeds += detection.weed_count
                total_crops += detection.crop_count

                # Count weed types
                for weed_type, count in weed_types_in_image.items():
                    all_weed_types[weed_type] = all_weed_types.get(weed_type, 0) + count

                # Store individual image analytics
                dominant_weed = max(weed_types_in_image.items(), key=lambda x: x[1])[0] if weed_types_in_image else None
                image_analytics.append({
                    "image_id": image.id,
                    "zone": image.zone_number,
                    "block": image.block_number,
                    "filename": image.original_filename,
                    "weeds": detection.weed_count,
                    "crops": detection.crop_count,
                    "weed_types": weed_types_in_image,
                    "dominant_weed": dominant_weed,
                    "infestation_score": detection.weed_count / (detection.weed_count + detection.crop_count) if (detection.weed_count + detection.crop_count) > 0 else 0
                })

                # Mark image as processed
                image.is_processed = True

        # Commit all detections in one batch
        db.commit()
        print(f"Committed {len(results)} detection results to database")
        
        # Calculate block and zone statistics
        block_statistics = []
        zone_statistics = []

        for zone_num in range(1, 10):
            zone_blocks = zone_results[zone_num]
            zone_weeds = 0
            zone_crops = 0
            zone_images = 0
            block_stats_for_zone = []

            # Calculate block statistics within this zone
            for block_num in range(1, 10):
                block_detections = zone_blocks[block_num]
                block_weeds = sum(d.weed_count for d in block_detections)
                block_crops = sum(d.crop_count for d in block_detections)

                # Calculate average area-based infestation percentage for the block
                block_infestation_pct = 0
                if block_detections:
                    block_infestation_pct = sum(d.infestation_percentage for d in block_detections) / len(block_detections)

                # Calculate block infestation level based on area percentage
                if block_infestation_pct > 30:  # More than 30% area coverage
                    block_level = "high"
                elif block_infestation_pct > 10:  # 10-30% area coverage
                    block_level = "medium"
                else:  # Less than 10% area coverage
                    block_level = "low"

                block_stat = {
                    "zone": zone_num,
                    "block": block_num,
                    "block_name": self._get_block_name(zone_num, block_num),
                    "images": len(block_detections),
                    "weeds": block_weeds,
                    "crops": block_crops,
                    "weed_density": round(block_weeds / len(block_detections), 2) if block_detections else 0,
                    "infestation_percentage": round(block_infestation_pct, 2),
                    "infestation_level": block_level
                }
                block_statistics.append(block_stat)
                block_stats_for_zone.append(block_stat)

                zone_weeds += block_weeds
                zone_crops += block_crops
                zone_images += len(block_detections)

            # Calculate average area-based infestation percentage for the zone
            # Average the block percentages
            zone_infestation_pct = 0
            if block_stats_for_zone:
                zone_infestation_pct = sum(b['infestation_percentage'] for b in block_stats_for_zone) / len(block_stats_for_zone)

            # Calculate zone infestation level based on area percentage
            if zone_infestation_pct > 30:  # More than 30% area coverage
                zone_level = "high"
            elif zone_infestation_pct > 10:  # 10-30% area coverage
                zone_level = "medium"
            else:  # Less than 10% area coverage
                zone_level = "low"

            zone_statistics.append({
                "zone": zone_num,
                "zone_name": self._get_zone_name(zone_num),
                "images_processed": zone_images,
                "weeds_detected": zone_weeds,
                "crops_detected": zone_crops,
                "weed_density": round(zone_weeds / zone_images, 2) if zone_images else 0,
                "infestation_percentage": round(zone_infestation_pct, 2),
                "infestation_level": zone_level,
                "blocks": block_stats_for_zone
            })
        
        # Identify hotspot zones (top 3 most infested by area percentage)
        sorted_zones = sorted(zone_statistics, key=lambda x: x['infestation_percentage'], reverse=True)
        hotspot_zones = [z['zone'] for z in sorted_zones[:3] if z['infestation_percentage'] > 0]

        # Calculate overall field infestation percentage (average of all zones)
        overall_infestation_pct = sum(z['infestation_percentage'] for z in zone_statistics) / len(zone_statistics) if zone_statistics else 0

        # Generate treatment recommendations
        treatment_priority = self._generate_treatment_recommendations(zone_statistics, all_weed_types)

        # Fetch satellite image for the field
        satellite_path = self._fetch_satellite_for_field(field)

        # Create field analysis record with all 4 levels
        analysis = FieldAnalysis(
            field_id=field_id,
            total_images_processed=len(images),
            total_weeds_detected=total_weeds,
            total_crops_detected=total_crops,
            overall_infestation_percentage=round(overall_infestation_pct, 2),
            zone_statistics=zone_statistics,
            block_statistics=block_statistics,
            image_statistics=image_analytics,
            weed_species_distribution=all_weed_types,
            hotspot_zones=hotspot_zones,
            treatment_priority=treatment_priority,
            satellite_image_path=satellite_path
        )
        
        db.add(analysis)
        field.is_processed = True
        db.commit()
        db.refresh(analysis)
        
        print(f"Processing complete! Analysis ID: {analysis.id}")
        return analysis
    
    def _process_images_parallel(self, images: List, confidence_threshold: float) -> List[Dict]:
        """
        Process images in parallel using ThreadPoolExecutor
        Significantly faster than sequential processing
        """
        results = []
        max_workers = min(8, os.cpu_count() or 4)  # Use up to 8 threads

        print(f"Processing {len(images)} images with {max_workers} parallel workers...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_image = {
                executor.submit(self.weed_service.predict_image, img.image_path, confidence_threshold): idx
                for idx, img in enumerate(images)
            }

            # Collect results in order
            results = [None] * len(images)
            completed = 0

            for future in as_completed(future_to_image):
                idx = future_to_image[future]
                try:
                    result = future.result()
                    results[idx] = result
                    completed += 1
                    if completed % 20 == 0:  # Progress updates every 20 images
                        print(f"  Processed {completed}/{len(images)} images...")
                except Exception as e:
                    print(f"  Error processing image {idx}: {e}")
                    results[idx] = {'success': False, 'error': str(e)}

        print(f"Completed processing all {len(images)} images!")
        return results

    def _count_weed_types(self, predictions: List[Dict]) -> Dict[str, int]:
        """Count occurrences of each weed type"""
        weed_counts = {}
        for pred in predictions:
            if pred.get('weed_type') == 'weed':
                class_name = pred['class_name']
                weed_counts[class_name] = weed_counts.get(class_name, 0) + 1
        return weed_counts
    
    def _get_zone_name(self, zone_num: int) -> str:
        """Get human-readable zone name"""
        zone_names = {
            1: "Top-Left", 2: "Top-Center", 3: "Top-Right",
            4: "Middle-Left", 5: "Middle-Center", 6: "Middle-Right",
            7: "Bottom-Left", 8: "Bottom-Center", 9: "Bottom-Right"
        }
        return zone_names.get(zone_num, f"Zone {zone_num}")

    def _get_block_name(self, zone_num: int, block_num: int) -> str:
        """Get human-readable block name"""
        block_positions = {
            1: "TL", 2: "TC", 3: "TR",
            4: "ML", 5: "MC", 6: "MR",
            7: "BL", 8: "BC", 9: "BR"
        }
        return f"Z{zone_num}-B{block_num} ({block_positions[block_num]})"
    
    def _generate_treatment_recommendations(self, zone_stats: List[Dict], 
                                          weed_types: Dict[str, int]) -> List[Dict]:
        """Generate treatment recommendations based on analysis"""
        recommendations = []
        
        # Priority 1: High infestation zones
        high_zones = [z for z in zone_stats if z['infestation_level'] == 'high']
        if high_zones:
            recommendations.append({
                "priority": 1,
                "action": "Immediate Treatment Required",
                "zones": [z['zone'] for z in high_zones],
                "description": f"Zones {', '.join(map(str, [z['zone'] for z in high_zones]))} show high weed infestation (>30% ratio)"
            })
        
        # Priority 2: Most common weed types
        if weed_types:
            top_weeds = sorted(weed_types.items(), key=lambda x: x[1], reverse=True)[:3]
            recommendations.append({
                "priority": 2,
                "action": "Target Specific Weed Species",
                "species": [w[0] for w in top_weeds],
                "description": f"Focus on controlling: {', '.join([w[0] for w in top_weeds])}"
            })
        
        # Priority 3: Medium infestation zones
        medium_zones = [z for z in zone_stats if z['infestation_level'] == 'medium']
        if medium_zones:
            recommendations.append({
                "priority": 3,
                "action": "Monitor and Prevent Spread",
                "zones": [z['zone'] for z in medium_zones],
                "description": f"Zones {', '.join(map(str, [z['zone'] for z in medium_zones]))} require monitoring"
            })

        return recommendations

    def _fetch_satellite_for_field(self, field: Field) -> str:
        """Fetch satellite image for the field"""
        try:
            # Try to fetch real satellite image
            satellite_path = self.satellite_service.fetch_satellite_image(
                center_lat=field.center_lat,
                center_lon=field.center_lon,
                hectares=field.size_hectares,
                image_size=640
            )

            # If API key not configured, create placeholder
            if not satellite_path:
                satellite_path = self.satellite_service.create_placeholder_image(
                    hectares=field.size_hectares,
                    image_size=640
                )

            return satellite_path

        except Exception as e:
            print(f"Error fetching satellite image: {e}")
            return None