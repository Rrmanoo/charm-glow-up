#!/bin/bash

# Weed Detection & Field Mapping System - Stop Script

echo "=================================="
echo "Weed Detection System - Stopping"
echo "=================================="
echo ""

# Check if containers are running
if ! docker-compose ps | grep -q "Up"; then
    echo "ℹ️  No running containers found"
    exit 0
fi

# Ask for confirmation
echo "This will stop all services. Data will be preserved."
echo "Press Ctrl+C to cancel or Enter to continue..."
read

# Stop services
echo "🛑 Stopping services..."
docker-compose stop

echo ""
echo "✅ Services stopped successfully!"
echo ""
echo "Data is preserved. To start again, run: ./start.sh"
echo "To remove all data, run: docker-compose down -v"
echo "=================================="
