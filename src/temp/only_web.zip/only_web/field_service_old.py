import os
import math
import requests
from typing import List, Dict, Tuple
from sqlalchemy.orm import Session
from database_models import Field, FieldImage, DetectionResult, FieldAnalysis
from datetime import datetime
import json

class FieldManagementService:
    """Service for managing agricultural fields and zones"""
    
    def __init__(self, satellite_api_key: str = None):
        self.satellite_api_key = satellite_api_key or os.getenv("GOOGLE_MAPS_API_KEY")
        self.images_base_path = "field_images"
        os.makedirs(self.images_base_path, exist_ok=True)
    
    def create_field(self, db: Session, name: str, center_lat: float, 
                     center_lon: float, size_hectares: float, 
                     location_name: str = None) -> Field:
        """
        Create a new field and calculate 9-zone grid
        
        Args:
            db: Database session
            name: Field name
            center_lat: Center latitude
            center_lon: Center longitude
            size_hectares: Field size in hectares
            location_name: Optional location description
        
        Returns:
            Field object
        """
        # Calculate approximate field dimensions
        # 1 hectare ≈ 100m x 100m
        # Approximate degrees per meter (varies by latitude)
        meters_per_degree_lat = 111320  # relatively constant
        meters_per_degree_lon = 111320 * math.cos(math.radians(center_lat))
        
        # Calculate field dimensions assuming square field
        side_length_meters = math.sqrt(size_hectares * 10000)  # hectares to m²
        
        lat_delta = side_length_meters / meters_per_degree_lat
        lon_delta = side_length_meters / meters_per_degree_lon
        
        # Calculate field boundaries
        boundary_coords = [
            [center_lat + lat_delta/2, center_lon - lon_delta/2],  # top-left
            [center_lat + lat_delta/2, center_lon + lon_delta/2],  # top-right
            [center_lat - lat_delta/2, center_lon + lon_delta/2],  # bottom-right
            [center_lat - lat_delta/2, center_lon - lon_delta/2],  # bottom-left
        ]
        
        # Calculate 9 grid zones (3x3)
        grid_zones = self._calculate_grid_zones(center_lat, center_lon, lat_delta, lon_delta)
        
        # Create field record
        field = Field(
            name=name,
            location_name=location_name,
            center_lat=center_lat,
            center_lon=center_lon,
            size_hectares=size_hectares,
            boundary_coords=boundary_coords,
            grid_zones=grid_zones
        )
        
        db.add(field)
        db.commit()
        db.refresh(field)
        
        return field
    
    def _calculate_grid_zones(self, center_lat: float, center_lon: float, 
                             lat_delta: float, lon_delta: float) -> Dict:
        """Calculate 9 zone boundaries for 3x3 grid"""
        zones = {}
        zone_mapping = {
            1: (0, 0), 2: (0, 1), 3: (0, 2),  # top row
            4: (1, 0), 5: (1, 1), 6: (1, 2),  # middle row
            7: (2, 0), 8: (2, 1), 9: (2, 2)   # bottom row
        }
        
        for zone_num, (row, col) in zone_mapping.items():
            # Calculate zone boundaries
            lat_start = center_lat + lat_delta/2 - (row * lat_delta/3) - lat_delta/6
            lat_end = lat_start - lat_delta/3
            lon_start = center_lon - lon_delta/2 + (col * lon_delta/3)
            lon_end = lon_start + lon_delta/3
            
            zones[zone_num] = {
                "zone_number": zone_num,
                "name": self._get_zone_name(zone_num),
                "bounds": {
                    "north": lat_start,
                    "south": lat_end,
                    "west": lon_start,
                    "east": lon_end
                },
                "center": {
                    "lat": (lat_start + lat_end) / 2,
                    "lon": (lon_start + lon_end) / 2
                }
            }
        
        return zones
    
    def _get_zone_name(self, zone_num: int) -> str:
        """Get human-readable zone name"""
        zone_names = {
            1: "Top-Left", 2: "Top-Center", 3: "Top-Right",
            4: "Middle-Left", 5: "Middle-Center", 6: "Middle-Right",
            7: "Bottom-Left", 8: "Bottom-Center", 9: "Bottom-Right"
        }
        return zone_names.get(zone_num, f"Zone {zone_num}")
    
    def save_field_image(self, db: Session, field_id: int, zone_number: int, 
                        file_content: bytes, original_filename: str) -> FieldImage:
        """Save an uploaded image for a specific field zone"""
        # Validate zone number
        if zone_number < 1 or zone_number > 9:
            raise ValueError("Zone number must be between 1 and 9")
        
        # Create directory structure: field_images/{field_id}/{zone_number}/
        zone_dir = os.path.join(self.images_base_path, str(field_id), str(zone_number))
        os.makedirs(zone_dir, exist_ok=True)
        
        # Generate unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        file_extension = os.path.splitext(original_filename)[1]
        filename = f"zone{zone_number}_{timestamp}{file_extension}"
        file_path = os.path.join(zone_dir, filename)
        
        # Save file
        with open(file_path, 'wb') as f:
            f.write(file_content)
        
        # Create database record
        field_image = FieldImage(
            field_id=field_id,
            zone_number=zone_number,
            image_path=file_path,
            original_filename=original_filename,
            file_size_bytes=len(file_content)
        )
        
        db.add(field_image)
        db.commit()
        db.refresh(field_image)
        
        return field_image
    
    def get_field_statistics(self, db: Session, field_id: int) -> Dict:
        """Get current upload statistics for a field"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            return None
        
        zone_stats = []
        for zone_num in range(1, 10):
            count = db.query(FieldImage).filter(
                FieldImage.field_id == field_id,
                FieldImage.zone_number == zone_num
            ).count()
            
            zone_stats.append({
                "zone": zone_num,
                "zone_name": self._get_zone_name(zone_num),
                "images_uploaded": count,
                "required_images": 50,
                "percentage": (count / 50) * 100
            })
        
        total_images = sum(z["images_uploaded"] for z in zone_stats)
        
        return {
            "field_id": field_id,
            "field_name": field.name,
            "total_images": total_images,
            "required_total": 450,  # 50 images × 9 zones
            "completion_percentage": (total_images / 450) * 100,
            "zones": zone_stats,
            "is_ready_for_processing": total_images >= 450
        }
    
    def fetch_satellite_image(self, field: Field, zoom: int = 16) -> str:
        """Fetch satellite image from Google Maps Static API"""
        if not self.satellite_api_key:
            raise ValueError("Satellite API key not configured")
        
        # Google Maps Static API endpoint
        base_url = "https://maps.googleapis.com/maps/api/staticmap"
        
        # Calculate map dimensions to cover field
        params = {
            "center": f"{field.center_lat},{field.center_lon}",
            "zoom": zoom,
            "size": "640x640",
            "maptype": "satellite",
            "key": self.satellite_api_key
        }
        
        # Add field boundary as path
        if field.boundary_coords:
            path_coords = "|".join([f"{lat},{lon}" for lat, lon in field.boundary_coords])
            params["path"] = f"color:0xff0000ff|weight:3|{path_coords}|{field.boundary_coords[0][0]},{field.boundary_coords[0][1]}"
        
        response = requests.get(base_url, params=params)
        
        if response.status_code == 200:
            # Save satellite image
            satellite_dir = os.path.join(self.images_base_path, str(field.id), "satellite")
            os.makedirs(satellite_dir, exist_ok=True)
            
            satellite_path = os.path.join(satellite_dir, "satellite_base.jpg")
            with open(satellite_path, 'wb') as f:
                f.write(response.content)
            
            return satellite_path
        else:
            raise Exception(f"Failed to fetch satellite image: {response.text}")

# Example usage
if __name__ == "__main__":
    from database_models import SessionLocal
    
    service = FieldManagementService()
    db = SessionLocal()
    
    # Create a test field
    field = service.create_field(
        db=db,
        name="Test Field Akmola",
        center_lat=51.1694,
        center_lon=71.4491,
        size_hectares=100,
        location_name="Astana, Kazakhstan"
    )
    
    print(f"Created field: {field.name} (ID: {field.id})")
    print(f"Grid zones: {json.dumps(field.grid_zones, indent=2)}")