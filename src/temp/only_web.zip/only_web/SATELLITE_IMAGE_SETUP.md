# Satellite Image Setup Guide

## Overview
The weed detection system now includes satellite imagery overlay for field visualization. The system fetches satellite images from Google Maps Static API based on the field's center coordinates and size in hectares.

## How It Works

1. **Field Coordinates**: When you create a field with center coordinates (lat, lon) and size in hectares, the system:
   - Calculates the field boundaries based on the center point and size
   - Determines the optimal zoom level to fit the entire field in the image
   - Fetches a 640x640 pixel satellite image from Google Maps

2. **Automatic Integration**: Satellite images are automatically fetched:
   - When processing a field (during `process_field_images`)
   - The satellite image is then overlaid with the 9-zone grid showing weed infestation levels

3. **Visualization**: The field analysis dashboard shows:
   - Satellite image with color-coded zones (green=low, orange=medium, red=high infestation)
   - Zone boundaries matching your field's actual geographic layout
   - Weed counts and statistics per zone

## Adding Your Google Maps API Key

### Step 1: Get a Google Maps API Key

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the **Maps Static API**
4. Go to "Credentials" and create an API key
5. Copy your API key

### Step 2: Add API Key to the Code

Open the file: `/home/crown/Server_train/satellite_service.py`

Find this line (around line 11):
```python
GOOGLE_MAPS_API_KEY = "YOUR_API_KEY_HERE"  # Replace with your actual API key
```

Replace `YOUR_API_KEY_HERE` with your actual Google Maps API key:
```python
GOOGLE_MAPS_API_KEY = "AIzaSyAaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQq"  # Your actual key
```

### Step 3: Restart the Application

```bash
docker-compose restart web
```

## Without API Key (Placeholder Mode)

If you don't add an API key, the system will automatically create placeholder satellite images with:
- Gray grid pattern
- Field size information
- Note indicating API key is required

The rest of the system will work normally - you just won't see real satellite imagery.

## Example Field Coordinates

For Kazakhstan (Astana region):
- **Center Lat**: 51.1694
- **Center Lon**: 71.4491
- **Size**: 100 hectares

The system will:
1. Calculate that 100 hectares = 1,000,000 m² ≈ 1km × 1km square
2. Fetch satellite image centered at (51.1694, 71.4491)
3. Use appropriate zoom level (around 15-16) to fit the entire field
4. Overlay a 3×3 zone grid on the image

## Zoom Level Calculation

The system automatically calculates the best zoom level based on field size:

| Field Size | Approximate Zoom Level |
|------------|----------------------|
| 1-10 ha    | 17-18 |
| 10-50 ha   | 16-17 |
| 50-200 ha  | 15-16 |
| 200+ ha    | 14-15 |

## File Structure

```
Server_train/
├── satellite_service.py          # Satellite image fetching (ADD API KEY HERE)
├── field_service.py               # Field management with satellite integration
├── batch_processing_service.py   # Processing with satellite images
├── visualization_service.py       # Overlays grid on satellite images
└── visualizations/
    └── satellite_images/          # Downloaded satellite images stored here
```

## Troubleshooting

**Issue**: "Warning: Google Maps API key not configured"
- **Solution**: Add your API key to `satellite_service.py` as described above

**Issue**: "Error fetching satellite image: 403 Forbidden"
- **Solution**: Make sure your API key has Maps Static API enabled

**Issue**: "Error fetching satellite image: Timeout"
- **Solution**: Check your internet connection

**Issue**: Images look zoomed in/out
- **Solution**: The zoom level is calculated automatically, but you can adjust the formula in `calculate_zoom_level()` method if needed

## API Usage & Costs

- **Free Tier**: Google Maps Static API offers $200 free credit per month
- **Cost**: After free tier, approximately $2 per 1,000 requests
- **Image Size**: We use 640×640 pixels (within free tier limits)
- **Caching**: Images are saved locally and reused to minimize API calls

## Testing

After adding your API key:

1. Go to: `http://192.168.0.59:8000/fields`
2. Create a new field with coordinates
3. Upload images and process the field
4. View the analysis - you should see real satellite imagery with your field grid overlay

## Security Note

⚠️ **Important**: Don't commit your API key to Git!

If you're using version control:
1. Add `satellite_service.py` to `.gitignore` after adding your key
2. Or use environment variables instead of hardcoding
