-- Initialize PostGIS extension
CREATE EXTENSION IF NOT EXISTS postgis;

-- Grant permissions
GRANT ALL PRIVILEGES ON DATABASE weed_detection_db TO weeduser;
