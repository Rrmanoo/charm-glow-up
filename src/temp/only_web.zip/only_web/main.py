import os
import tempfile
import cv2
import numpy as np
from pathlib import Path
import base64
from PIL import Image
import logging
from typing import List, Dict
from datetime import datetime
from fastapi import FastAPI, File, UploadFile, HTTPException, Form, Depends
from fastapi.responses import HTMLResponse
from ultralytics import YOLO
from sqlalchemy.orm import Session

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Import new field mapping services
try:
    from database_models import get_db, Field, FieldImage, FieldAnalysis, DetectionResult, init_database
    from field_service import FieldManagementService
    from batch_processing_service import BatchProcessingService
    from visualization_service import VisualizationService
    FIELD_MAPPING_ENABLED = True
except Exception as e:
    logger.info(f"Field mapping features disabled: {e}")
    FIELD_MAPPING_ENABLED = False

# Install required packages
def install_requirements():
    """Install required packages if not already installed"""
    import subprocess
    import sys
    packages = ['fastapi', 'uvicorn', 'python-multipart', 'ultralytics', 'opencv-python', 'pillow', 'numpy']
    for package in packages:
        try:
            if package == 'opencv-python':
                __import__('cv2')
            elif package == 'python-multipart':
                continue
            else:
                __import__(package.replace('-', '_'))
        except ImportError:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

try:
    install_requirements()
except Exception as e:
    print(f"Warning: Could not install all requirements: {e}")

class WeedDetectionService:
    """Service class for weed detection and classification"""
    def __init__(self, model_path: str = "weed_classification_final_model.pt"):
        self.model_path = model_path
        self.model = None
        self.class_colors = {}
        self.load_model()

    def load_model(self):
        """Load the trained YOLO model"""
        try:
            if not os.path.exists(self.model_path):
                print(f"Warning: Model file not found: {self.model_path}")
                self.model = None
                return

            # Patch torch.load to allow loading custom models (PyTorch 2.6+ compatibility)
            import torch
            original_load = torch.load

            def patched_load(*args, **kwargs):
                # Force weights_only=False for trusted model files
                kwargs['weights_only'] = False
                return original_load(*args, **kwargs)

            torch.load = patched_load

            try:
                self.model = YOLO(self.model_path)
                logger.info(f"Model loaded successfully from {self.model_path}")
            finally:
                # Restore original torch.load
                torch.load = original_load
            if self.model.names:
                colors = [
                    (255, 69, 0),    # OrangeRed
                    (50, 205, 50),   # LimeGreen
                    (65, 105, 225),  # RoyalBlue
                    (255, 215, 0),   # Gold
                    (199, 21, 133),  # MediumVioletRed
                    (32, 178, 170),  # LightSeaGreen
                    (255, 140, 0),   # DarkOrange
                    (147, 112, 219)  # MediumPurple
                ]
                for i, name in self.model.names.items():
                    self.class_colors[i] = colors[i % len(colors)]
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            self.model = None

    def predict_image(self, image_path: str, conf_threshold: float = 0.25) -> dict:
        """Predict weeds in an image with enhanced bounding boxes and labels"""
        try:
            if self.model is None:
                return {
                    'success': False,
                    'error': 'Model not loaded.',
                    'predictions': [],
                    'summary': {},
                    'annotated_image_base64': None
                }
            results = self.model.predict(image_path, conf=conf_threshold, verbose=False)
            predictions = []
            original_image = cv2.imread(image_path)
            annotated_image = original_image.copy()
            for result in results:
                boxes = result.boxes
                if boxes is not None:
                    for box in boxes:
                        class_id = int(box.cls)
                        confidence = float(box.conf)
                        bbox = box.xyxy[0].tolist()
                        class_name = self.model.names[class_id]
                        prediction = {
                            'class_id': class_id,
                            'class_name': class_name,
                            'confidence': confidence,
                            'bbox': bbox,
                            'weed_type': 'weed' if 'weed:' in class_name.lower() else 'crop'
                        }
                        predictions.append(prediction)
                        x1, y1, x2, y2 = map(int, bbox)
                        color = self.class_colors.get(class_id, (0, 255, 0))

                        # Draw thicker bounding box with a subtle shadow effect
                        thickness = 3
                        shadow_offset = 2
                        shadow_color = (50, 50, 50)  # Dark gray for shadow
                        # Draw shadow box slightly offset
                        cv2.rectangle(annotated_image, (x1 + shadow_offset, y1 + shadow_offset),
                                      (x2 + shadow_offset, y2 + shadow_offset), shadow_color, thickness)
                        # Draw main box
                        cv2.rectangle(annotated_image, (x1, y1), (x2, y2), color, thickness)

                        # Prepare label with background for better readability
                        label = f"{class_name}: {confidence:.2f}"
                        font = cv2.FONT_HERSHEY_SIMPLEX
                        font_scale = 0.7
                        font_thickness = 2
                        text_size = cv2.getTextSize(label, font, font_scale, font_thickness)[0]

                        # Background rectangle for text
                        text_bg_top_left = (x1, y1 - text_size[1] - 10)
                        text_bg_bottom_right = (x1 + text_size[0] + 10, y1)
                        bg_color = (255, 255, 255)  # White background
                        cv2.rectangle(annotated_image, text_bg_top_left, text_bg_bottom_right, bg_color, -1)

                        # Draw shadow for text
                        text_pos_shadow = (x1 + 5 + shadow_offset, y1 - 5 + shadow_offset)
                        cv2.putText(annotated_image, label, text_pos_shadow, font, font_scale,
                                    shadow_color, font_thickness, cv2.LINE_AA)

                        # Draw main text
                        text_pos = (x1 + 5, y1 - 5)
                        cv2.putText(annotated_image, label, text_pos, font, font_scale,
                                    color, font_thickness, cv2.LINE_AA)

            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.jpg')
            cv2.imwrite(temp_file.name, annotated_image)
            with open(temp_file.name, 'rb') as img_file:
                img_base64 = base64.b64encode(img_file.read()).decode()
            os.remove(temp_file.name)

            # Calculate area-based statistics
            weed_count = len([p for p in predictions if p['weed_type'] == 'weed'])
            crop_count = len([p for p in predictions if p['weed_type'] == 'crop'])

            # Calculate total image area
            image_height, image_width = original_image.shape[:2]
            total_image_area = image_height * image_width

            # Calculate total weed bounding box area (sum of all weed bboxes)
            total_weed_bbox_area = 0
            for pred in predictions:
                if pred['weed_type'] == 'weed':
                    bbox = pred['bbox']
                    x1, y1, x2, y2 = bbox
                    bbox_area = (x2 - x1) * (y2 - y1)
                    total_weed_bbox_area += bbox_area

            # Apply 70% factor (assuming weeds don't fully fill bounding boxes)
            actual_weed_area = total_weed_bbox_area * 0.7

            # Calculate infestation percentage based on image area coverage
            infestation_percentage = 0
            if total_image_area > 0:
                infestation_percentage = round((actual_weed_area / total_image_area) * 100, 2)

            return {
                'success': True,
                'predictions': predictions,
                'summary': {
                    'total_detections': len(predictions),
                    'weed_count': weed_count,
                    'crop_count': crop_count,
                    'weed_types': list(set([p['class_name'] for p in predictions if p['weed_type'] == 'weed'])),
                    'total_weed_bbox_area': total_weed_bbox_area,
                    'actual_weed_area': actual_weed_area,
                    'total_image_area': total_image_area,
                    'infestation_percentage': infestation_percentage
                },
                'annotated_image_base64': img_base64
            }
        except Exception as e:
            logger.error(f"Error in image prediction: {e}")
            return {
                'success': False,
                'error': str(e),
                'predictions': [],
                'summary': {},
                'annotated_image_base64': None
            }

# Initialize the service
weed_service = WeedDetectionService()

# Initialize field mapping services (if enabled)
if FIELD_MAPPING_ENABLED:
    try:
        field_service = FieldManagementService()
        batch_service = BatchProcessingService(weed_service)
        viz_service = VisualizationService()
        # Initialize database tables
        init_database()
        logger.info("Field mapping services initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize field mapping services: {e}")
        FIELD_MAPPING_ENABLED = False

# FastAPI App
app = FastAPI(
    title="Weed Classification & Field Mapping API",
    description="API for detecting and classifying weeds in images, with field mapping capabilities",
    version="2.0.0"
)

@app.get("/", response_class=HTMLResponse)
async def root():
    """Root endpoint with styled HTML form for image uploads"""
    model_status = "Yes" if weed_service.model is not None else "No (Demo Mode)"
    html_content = f"""
    <html>
        <head>
            <title>Weed Classification API</title>
            <style>
                body {{
                    font-family: 'Segoe UI', Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background-color: #f4f7f6;
                    color: #333;
                }}
                .container {{
                    max-width: 800px;
                    margin: 50px auto;
                    padding: 20px;
                    background-color: white;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                }}
                h1 {{
                    color: #2e7d32;
                    text-align: center;
                    font-size: 2.5em;
                }}
                h2 {{
                    color: #388e3c;
                    margin-top: 20px;
                }}
                p.status {{
                    text-align: center;
                    font-size: 1.1em;
                    color: { '#388e3c' if weed_service.model is not None else '#d32f2f' };
                }}
                form {{
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    margin-top: 20px;
                }}
                input[type="file"] {{
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                }}
                input[type="number"] {{
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    width: 200px;
                }}
                input[type="submit"] {{
                    background-color: #4caf50;
                    color: white;
                    padding: 12px 20px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 1.1em;
                    transition: background-color 0.3s;
                }}
                input[type="submit"]:hover {{
                    background-color: #388e3c;
                }}
                a {{
                    color: #4caf50;
                    text-decoration: none;
                    font-weight: bold;
                }}
                a:hover {{
                    text-decoration: underline;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 20px;
                    font-size: 0.9em;
                    color: #666;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🌱 Weed Classification API</h1>
                <p class="status"><b>Model Loaded:</b> {model_status}</p>
                <h2>Upload Image for Weed Detection</h2>
                <form action="/predict/image" enctype="multipart/form-data" method="post">
                    <input type="file" name="file" accept="image/*" required>
                    <input type="number" name="confidence" value="0.25" step="0.01" min="0.1" max="0.9" placeholder="Confidence Threshold">
                    <input type="submit" value="Detect Weeds">
                </form>
                <div class="footer">
                    <p><a href="/docs">API Documentation</a> | <a href="/fields">Field Mapping Dashboard</a></p>
                    <p>Powered by YOLOv8 | Version 2.0.0</p>
                </div>
            </div>
        </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.post("/predict/image")
async def predict_image(file: UploadFile = File(...), confidence: float = Form(default=0.25)):
    """Predict weeds in an uploaded image"""
    try:
        if not file.content_type.startswith('image/'):
            raise HTTPException(status_code=400, detail="File must be an image")
        with tempfile.NamedTemporaryFile(delete=False, suffix=".jpg") as temp_file:
            content = await file.read()
            temp_file.write(content)
            temp_file_path = temp_file.name
        result = weed_service.predict_image(temp_file_path, confidence)
        os.remove(temp_file_path)
        if result['success'] and result['annotated_image_base64']:
            # Calculate detailed statistics
            weed_count = result['summary']['weed_count']
            crop_count = result['summary']['crop_count']
            total_detections = result['summary']['total_detections']

            # Get area-based infestation percentage (already calculated in predict_image)
            infestation_rate = result['summary'].get('infestation_percentage', 0)

            # Get area information for display
            total_weed_bbox_area = result['summary'].get('total_weed_bbox_area', 0)
            actual_weed_area = result['summary'].get('actual_weed_area', 0)
            total_image_area = result['summary'].get('total_image_area', 1)

            # Determine infestation level based on area coverage
            infestation_level = "Low"
            infestation_color = "#4caf50"
            if infestation_rate > 30:  # More than 30% area coverage is high
                infestation_level = "High"
                infestation_color = "#f44336"
            elif infestation_rate > 10:  # 10-30% area coverage is medium
                infestation_level = "Medium"
                infestation_color = "#ff9800"

            # Count weed types
            weed_types_list = result['summary']['weed_types']
            weed_types_html = ""
            if weed_types_list:
                for weed_type in weed_types_list:
                    weed_types_html += f'<li>{weed_type}</li>'
            else:
                weed_types_html = '<li>No weeds detected</li>'

            # Generate recommendations based on area coverage
            recommendations_html = ""
            coverage_info = f"<p><strong>Coverage Details:</strong> Weeds cover approximately {infestation_rate}% of the image area ({int(actual_weed_area):,} pixels of {int(total_image_area):,} total pixels, adjusted with 70% fill factor).</p>"

            if infestation_rate > 30:
                recommendations_html = f"""
                <div class="recommendation high">
                    <h3>🚨 High Infestation Alert</h3>
                    <p>Immediate action required! Weeds are covering more than 30% of the monitored area.</p>
                    {coverage_info}
                    <ul>
                        <li>Apply targeted herbicide treatment to affected zones</li>
                        <li>Consider mechanical removal for dense weed clusters</li>
                        <li>Schedule follow-up inspection within 7 days</li>
                        <li>Implement intensive weed management strategy</li>
                    </ul>
                </div>
                """
            elif infestation_rate > 10:
                recommendations_html = f"""
                <div class="recommendation medium">
                    <h3>⚠️ Moderate Infestation</h3>
                    <p>This area requires attention to prevent further spread (10-30% area coverage).</p>
                    {coverage_info}
                    <ul>
                        <li>Monitor closely and apply spot treatment to weed patches</li>
                        <li>Schedule treatment within 2 weeks</li>
                        <li>Implement preventive measures in surrounding areas</li>
                        <li>Consider cultural control methods</li>
                    </ul>
                </div>
                """
            else:
                recommendations_html = f"""
                <div class="recommendation low">
                    <h3>✅ Low Infestation</h3>
                    <p>This area is in good condition with minimal weed pressure (less than 10% coverage).</p>
                    {coverage_info}
                    <ul>
                        <li>Continue regular monitoring</li>
                        <li>Maintain current crop management practices</li>
                        <li>Spot treat any isolated weed patches as needed</li>
                        <li>Document location for trend analysis</li>
                    </ul>
                </div>
                """

            html_content = f"""
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Weed Detection Analysis Results</title>
                <style>
                    * {{
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box;
                    }}
                    body {{
                        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        padding: 20px;
                        color: #333;
                        min-height: 100vh;
                    }}
                    .container {{
                        max-width: 1200px;
                        margin: 0 auto;
                        background: white;
                        border-radius: 15px;
                        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                        overflow: hidden;
                    }}
                    .header {{
                        background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
                        color: white;
                        padding: 30px;
                        text-align: center;
                    }}
                    .header h1 {{
                        font-size: 2.5em;
                        margin-bottom: 10px;
                    }}
                    .header p {{
                        font-size: 1.2em;
                        opacity: 0.9;
                    }}
                    .stats-grid {{
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                        gap: 20px;
                        padding: 30px;
                        background: #f5f5f5;
                    }}
                    .stat-card {{
                        background: white;
                        padding: 25px;
                        border-radius: 10px;
                        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                        text-align: center;
                        transition: transform 0.3s;
                    }}
                    .stat-card:hover {{
                        transform: translateY(-5px);
                        box-shadow: 0 8px 12px rgba(0,0,0,0.15);
                    }}
                    .stat-card .value {{
                        font-size: 3em;
                        font-weight: bold;
                        color: #2e7d32;
                        margin: 10px 0;
                    }}
                    .stat-card .label {{
                        font-size: 1.1em;
                        color: #666;
                        text-transform: uppercase;
                        letter-spacing: 1px;
                    }}
                    .stat-card.infestation {{
                        border-top: 5px solid {infestation_color};
                    }}
                    .stat-card.infestation .value {{
                        color: {infestation_color};
                    }}
                    .image-section {{
                        padding: 30px;
                    }}
                    .image-section img {{
                        width: 100%;
                        border-radius: 10px;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                    }}
                    .image-section h2 {{
                        color: #2e7d32;
                        margin-bottom: 20px;
                        text-align: center;
                        font-size: 1.8em;
                    }}
                    .details-section {{
                        padding: 30px;
                        background: #f9f9f9;
                    }}
                    .details-section h2 {{
                        color: #2e7d32;
                        margin-bottom: 20px;
                        font-size: 1.8em;
                    }}
                    .weed-types {{
                        background: white;
                        padding: 20px;
                        border-radius: 10px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                        margin-bottom: 20px;
                    }}
                    .weed-types h3 {{
                        color: #d32f2f;
                        margin-bottom: 15px;
                    }}
                    .weed-types ul {{
                        list-style: none;
                        padding-left: 0;
                    }}
                    .weed-types li {{
                        padding: 8px 0;
                        border-bottom: 1px solid #eee;
                    }}
                    .weed-types li:before {{
                        content: "🌿 ";
                        margin-right: 8px;
                    }}
                    .recommendations {{
                        padding: 30px;
                        background: #fff9e6;
                    }}
                    .recommendations h2 {{
                        color: #856404;
                        margin-bottom: 20px;
                        font-size: 1.8em;
                    }}
                    .recommendation {{
                        background: white;
                        padding: 20px;
                        margin-bottom: 20px;
                        border-radius: 10px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }}
                    .recommendation.high {{
                        border-left: 5px solid #f44336;
                    }}
                    .recommendation.medium {{
                        border-left: 5px solid #ff9800;
                    }}
                    .recommendation.low {{
                        border-left: 5px solid #4caf50;
                    }}
                    .recommendation h3 {{
                        margin-bottom: 15px;
                        font-size: 1.4em;
                    }}
                    .recommendation ul {{
                        margin-top: 15px;
                        padding-left: 25px;
                    }}
                    .recommendation li {{
                        margin-bottom: 8px;
                        line-height: 1.6;
                    }}
                    .actions {{
                        padding: 30px;
                        text-align: center;
                        background: white;
                    }}
                    .btn {{
                        display: inline-block;
                        background-color: #4caf50;
                        color: white;
                        padding: 15px 30px;
                        border-radius: 5px;
                        text-decoration: none;
                        margin: 10px;
                        font-weight: bold;
                        font-size: 1.1em;
                        transition: background-color 0.3s;
                    }}
                    .btn:hover {{
                        background-color: #388e3c;
                    }}
                    .footer {{
                        padding: 20px;
                        text-align: center;
                        background: #f5f5f5;
                        color: #666;
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>🌱 Weed Detection Analysis</h1>
                        <p>Comprehensive Image Analysis Results</p>
                    </div>

                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="label">Total Detections</div>
                            <div class="value">{total_detections}</div>
                        </div>
                        <div class="stat-card">
                            <div class="label">Weeds Detected</div>
                            <div class="value" style="color: #d32f2f;">{weed_count}</div>
                        </div>
                        <div class="stat-card">
                            <div class="label">Crops Detected</div>
                            <div class="value" style="color: #4caf50;">{crop_count}</div>
                        </div>
                        <div class="stat-card infestation">
                            <div class="label">Infestation Rate</div>
                            <div class="value">{infestation_rate}%</div>
                            <div style="color: {infestation_color}; font-weight: bold; margin-top: 10px;">{infestation_level}</div>
                        </div>
                    </div>

                    <div class="image-section">
                        <h2>📷 Annotated Image with Detections</h2>
                        <img src="data:image/jpeg;base64,{result['annotated_image_base64']}" alt="Annotated Image with Weed Detections">
                    </div>

                    <div class="details-section">
                        <h2>📊 Detection Details</h2>
                        <div class="weed-types">
                            <h3>Detected Weed Species:</h3>
                            <ul>
                                {weed_types_html}
                            </ul>
                        </div>
                    </div>

                    <div class="recommendations">
                        <h2>💡 Treatment Recommendations</h2>
                        {recommendations_html}
                    </div>

                    <div class="actions">
                        <a href="/" class="btn">Upload Another Image</a>
                        <a href="/fields" class="btn" style="background-color: #2196f3;">View Field Mapping</a>
                    </div>

                    <div class="footer">
                        <p>Powered by YOLOv8 Deep Learning Model | Weed Classification API v2.0.0</p>
                        <p style="margin-top: 10px; font-size: 0.9em;">Generated on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
                    </div>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=html_content)
        else:
            html_content = f"""
            <html>
                <head>
                    <title>Image Prediction Results</title>
                    <style>
                        body {{
                            font-family: 'Segoe UI', Arial, sans-serif;
                            margin: 0;
                            padding: 0;
                            background-color: #f4f7f6;
                            color: #333;
                        }}
                        .container {{
                            max-width: 800px;
                            margin: 50px auto;
                            padding: 20px;
                            background-color: white;
                            border-radius: 10px;
                            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                        }}
                        h1 {{
                            color: #2e7d32;
                            text-align: center;
                        }}
                        .error-box {{
                            background-color: #ffebee;
                            padding: 15px;
                            border-radius: 5px;
                            color: #d32f2f;
                        }}
                        a {{
                            display: inline-block;
                            background-color: #4caf50;
                            color: white;
                            padding: 10px 20px;
                            border-radius: 5px;
                            text-decoration: none;
                            margin-top: 20px;
                            font-weight: bold;
                        }}
                        a:hover {{
                            background-color: #388e3c;
                        }}
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>Image Prediction Results</h1>
                        <div class="error-box">
                            <p>Error: {result.get('error', 'No detections made')}</p>
                        </div>
                        <a href="/">Back to Upload</a>
                    </div>
                </body>
            </html>
            """
            return HTMLResponse(content=html_content)
    except Exception as e:
        logger.error(f"Error in image prediction endpoint: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# FIELD MAPPING ENDPOINTS
# ============================================================================

if FIELD_MAPPING_ENABLED:

    @app.get("/fields", response_class=HTMLResponse)
    async def list_fields(db: Session = Depends(get_db)):
        """Display all fields with management interface"""
        fields = db.query(Field).all()

        fields_html = ""
        for field in fields:
            stats = field_service.get_field_statistics(db, field.id)
            status = "✅ Ready" if stats['is_ready_for_processing'] else f"📤 {stats['completion_percentage']:.1f}%"

            fields_html += f"""
            <div class="field-card">
                <h3>{field.name}</h3>
                <p><strong>Location:</strong> {field.location_name or 'N/A'}</p>
                <p><strong>Size:</strong> {field.size_hectares} hectares</p>
                <p><strong>Status:</strong> {status}</p>
                <p><strong>Images:</strong> {stats['total_images']}/324</p>
                <div class="actions">
                    <a href="/fields/{field.id}/upload-zip-form" class="btn" style="background: #ff9800;">📁 Upload ZIP</a>
                    <a href="/fields/{field.id}/statistics" class="btn">View Stats</a>
                    {'<a href="/fields/' + str(field.id) + '/process-form" class="btn process">Process Field</a>' if stats['is_ready_for_processing'] else ''}
                    {'<a href="/fields/' + str(field.id) + '/view-analysis" class="btn">View Analysis</a>' if field.is_processed else ''}
                </div>
            </div>
            """

        html_content = f"""
        <html>
        <head>
            <title>Field Management Dashboard</title>
            <style>
                body {{
                    font-family: 'Segoe UI', Arial, sans-serif;
                    margin: 0;
                    padding: 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                }}
                .container {{
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                }}
                h1 {{
                    color: white;
                    text-align: center;
                    font-size: 2.5em;
                    margin-bottom: 30px;
                }}
                .field-card {{
                    background: white;
                    padding: 25px;
                    margin: 20px 0;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                }}
                .field-card h3 {{
                    color: #2e7d32;
                    margin-top: 0;
                }}
                .actions {{
                    margin-top: 15px;
                }}
                .btn {{
                    display: inline-block;
                    background: #4caf50;
                    color: white;
                    padding: 10px 20px;
                    margin: 5px;
                    border-radius: 5px;
                    text-decoration: none;
                    font-weight: bold;
                }}
                .btn:hover {{
                    background: #388e3c;
                }}
                .btn.process {{
                    background: #ff9800;
                }}
                .btn.process:hover {{
                    background: #f57c00;
                }}
                .create-field {{
                    background: #2196f3;
                    color: white;
                    padding: 15px 30px;
                    border-radius: 5px;
                    text-decoration: none;
                    display: inline-block;
                    margin: 20px 0;
                    font-weight: bold;
                }}
                .create-field:hover {{
                    background: #1976d2;
                }}
                .back-link {{
                    color: white;
                    text-decoration: none;
                    font-size: 1.1em;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <a href="/" class="back-link">← Back to Home</a>
                <h1>🌾 Field Management Dashboard</h1>
                <a href="/fields/create-form" class="create-field">+ Create New Field</a>
                <div id="fields">
                    {fields_html if fields else '<p style="color: white; text-align: center; font-size: 1.2em;">No fields yet. Create your first field!</p>'}
                </div>
            </div>
        </body>
        </html>
        """

        return HTMLResponse(content=html_content)

    @app.get("/fields/create-form", response_class=HTMLResponse)
    async def create_field_form():
        """Form for creating a new field"""
        html_content = """
        <html>
        <head>
            <title>Create New Field</title>
            <style>
                body {
                    font-family: 'Segoe UI', Arial, sans-serif;
                    margin: 0;
                    padding: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                }
                .container {
                    max-width: 600px;
                    margin: 50px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                }
                h1 {
                    color: #2e7d32;
                    text-align: center;
                }
                form {
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                }
                label {
                    font-weight: bold;
                    color: #333;
                }
                input, textarea {
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    font-size: 1em;
                }
                input[type="submit"] {
                    background: #4caf50;
                    color: white;
                    border: none;
                    cursor: pointer;
                    font-weight: bold;
                    padding: 12px;
                }
                input[type="submit"]:hover {
                    background: #388e3c;
                }
                .back-link {
                    text-align: center;
                    margin-top: 20px;
                }
                .back-link a {
                    color: #2196f3;
                    text-decoration: none;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Create New Field</h1>
                <form action="/fields/create" method="post">
                    <label>Field Name:</label>
                    <input type="text" name="name" required placeholder="e.g., North Field Astana">

                    <label>Center Latitude:</label>
                    <input type="number" step="0.000001" name="center_lat" required placeholder="e.g., 51.1694">

                    <label>Center Longitude:</label>
                    <input type="number" step="0.000001" name="center_lon" required placeholder="e.g., 71.4491">

                    <label>Size (hectares):</label>
                    <input type="number" step="0.1" name="size_hectares" required placeholder="e.g., 100">

                    <label>Location Description (optional):</label>
                    <input type="text" name="location_name" placeholder="e.g., Akmola Region, Kazakhstan">

                    <input type="submit" value="Create Field">
                </form>
                <div class="back-link">
                    <a href="/fields">← Back to Fields</a>
                </div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)

    @app.post("/fields/create", response_class=HTMLResponse)
    async def create_field(
        name: str = Form(...),
        center_lat: float = Form(...),
        center_lon: float = Form(...),
        size_hectares: float = Form(...),
        location_name: str = Form(None),
        db: Session = Depends(get_db)
    ):
        """Create a new agricultural field"""
        try:
            field = field_service.create_field(
                db=db,
                name=name,
                center_lat=center_lat,
                center_lon=center_lon,
                size_hectares=size_hectares,
                location_name=location_name
            )

            html_content = f"""
            <html>
            <head>
                <title>Field Created</title>
                <meta http-equiv="refresh" content="2;url=/fields" />
                <style>
                    body {{
                        font-family: Arial, sans-serif;
                        text-align: center;
                        padding: 50px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                        color: white;
                    }}
                    .success {{
                        background: white;
                        color: #2e7d32;
                        padding: 30px;
                        border-radius: 10px;
                        display: inline-block;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                    }}
                </style>
            </head>
            <body>
                <div class="success">
                    <h1>✅ Field Created Successfully!</h1>
                    <p><strong>{field.name}</strong> has been created with 9 zones.</p>
                    <p>Redirecting to fields dashboard...</p>
                    <p><a href="/fields">Click here if not redirected</a></p>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=html_content)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/fields/{field_id}/upload-zip-form", response_class=HTMLResponse)
    async def upload_zip_form(field_id: int, db: Session = Depends(get_db)):
        """Form for uploading ZIP file with folder structure"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise HTTPException(status_code=404, detail="Field not found")

        stats = field_service.get_field_statistics(db, field_id)

        html_content = f"""
        <html>
        <head>
            <title>Upload ZIP - {field.name}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                }}
                .container {{
                    max-width: 900px;
                    margin: 50px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                }}
                h1 {{
                    color: #2e7d32;
                }}
                .info-box {{
                    background: #e3f2fd;
                    padding: 20px;
                    border-radius: 5px;
                    margin: 20px 0;
                }}
                .folder-structure {{
                    background: #f5f5f5;
                    padding: 15px;
                    border-radius: 5px;
                    font-family: monospace;
                    font-size: 0.9em;
                    white-space: pre;
                }}
                form {{
                    margin-top: 30px;
                }}
                input[type="file"] {{
                    padding: 10px;
                    border: 2px dashed #ccc;
                    border-radius: 5px;
                    width: 100%;
                    cursor: pointer;
                }}
                input[type="submit"] {{
                    background: #4caf50;
                    color: white;
                    border: none;
                    padding: 15px 30px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    font-size: 1.1em;
                    margin-top: 20px;
                }}
                .stats {{
                    background: #e8f5e9;
                    padding: 15px;
                    border-radius: 5px;
                    margin: 20px 0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Upload ZIP File for {field.name}</h1>

                <div class="stats">
                    <p><strong>Current Progress:</strong> {stats['total_images']}/324 images ({stats['completion_percentage']:.1f}%)</p>
                </div>

                <div class="info-box">
                    <h3>📁 Required Folder Structure:</h3>
                    <p>Your ZIP file should contain a folder with this exact structure:</p>
                    <div class="folder-structure">my_field_data/
├── zone_1/
│   ├── block_1/
│   │   ├── image1.jpg
│   │   ├── image2.jpg
│   │   ├── image3.jpg
│   │   └── image4.jpg
│   ├── block_2/
│   │   └── ... (4 images)
│   └── ... (9 blocks total)
├── zone_2/
│   └── ... (9 blocks, 36 images)
└── ... (9 zones total)

<strong>Total: 324 images</strong>
- 9 zones (zone_1 to zone_9)
- 9 blocks per zone (block_1 to block_9)
- 4 images per block (.jpg or .png)</div>
                </div>

                <form action="/fields/{field_id}/upload-zip" method="post" enctype="multipart/form-data">
                    <h3>Select ZIP File:</h3>
                    <input type="file" name="zipfile" accept=".zip" required>
                    <input type="submit" value="Upload and Process ZIP">
                </form>

                <div style="margin-top: 20px; text-align: center;">
                    <a href="/fields" style="color: #2196f3;">← Back to Fields</a>
                </div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)

    @app.post("/fields/{field_id}/upload-zip", response_class=HTMLResponse)
    async def upload_zip(
        field_id: int,
        zipfile: UploadFile = File(...),
        db: Session = Depends(get_db)
    ):
        """Process uploaded ZIP file with folder structure"""
        try:
            # Save uploaded file temporarily
            temp_zip_path = f"/tmp/field_{field_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.zip"
            with open(temp_zip_path, "wb") as buffer:
                content = await zipfile.read()
                buffer.write(content)

            # Process the ZIP file
            stats = field_service.process_folder_upload(db, field_id, temp_zip_path)

            # Clean up temp file
            os.remove(temp_zip_path)

            updated_stats = field_service.get_field_statistics(db, field_id)

            html_content = f"""
            <html>
            <head>
                <title>Upload Complete</title>
                <meta http-equiv="refresh" content="3;url=/fields" />
                <style>
                    body {{
                        font-family: Arial, sans-serif;
                        text-align: center;
                        padding: 50px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    }}
                    .success {{
                        background: white;
                        padding: 30px;
                        border-radius: 10px;
                        display: inline-block;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                    }}
                    .stats {{
                        background: #e8f5e9;
                        padding: 15px;
                        border-radius: 5px;
                        margin: 20px 0;
                        text-align: left;
                    }}
                </style>
            </head>
            <body>
                <div class="success">
                    <h1>✅ ZIP Upload Successful!</h1>
                    <div class="stats">
                        <p><strong>Processed:</strong> {stats['total_images']} images</p>
                        <p><strong>Zones found:</strong> {stats['zones_found']}</p>
                        <p><strong>Blocks found:</strong> {stats['blocks_found']}</p>
                        <p><strong>Total Progress:</strong> {updated_stats['total_images']}/324 images ({updated_stats['completion_percentage']:.1f}%)</p>
                        {f"<p style='color: red;'><strong>Errors:</strong> {len(stats['errors'])}</p>" if stats['errors'] else ""}
                    </div>
                    <p>Redirecting to fields dashboard...</p>
                    <p><a href="/fields">Click here if not redirected</a></p>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=html_content)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/fields/{field_id}/upload-form", response_class=HTMLResponse)
    async def upload_form(field_id: int, db: Session = Depends(get_db)):
        """Form for uploading images to a field zone"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise HTTPException(status_code=404, detail="Field not found")

        stats = field_service.get_field_statistics(db, field_id)

        zone_options = ""
        for zone in stats['zones']:
            zone_options += f'<option value="{zone["zone"]}">Zone {zone["zone"]} - {zone["zone_name"]} ({zone["images_uploaded"]}/50 images)</option>'

        html_content = f"""
        <html>
        <head>
            <title>Upload Images - {field.name}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                }}
                .container {{
                    max-width: 800px;
                    margin: 50px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                }}
                h1 {{
                    color: #2e7d32;
                }}
                form {{
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                }}
                select, input {{
                    padding: 10px;
                    border: 1px solid #ccc;
                    border-radius: 5px;
                    font-size: 1em;
                }}
                input[type="submit"] {{
                    background: #4caf50;
                    color: white;
                    border: none;
                    cursor: pointer;
                    font-weight: bold;
                }}
                .stats {{
                    background: #e8f5e9;
                    padding: 15px;
                    border-radius: 5px;
                    margin-bottom: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Upload Images for {field.name}</h1>
                <div class="stats">
                    <p><strong>Total Progress:</strong> {stats['total_images']}/450 images ({stats['completion_percentage']:.1f}%)</p>
                </div>
                <form action="/fields/{field_id}/upload-zone-images" method="post" enctype="multipart/form-data">
                    <label><strong>Select Zone:</strong></label>
                    <select name="zone_number" required>
                        {zone_options}
                    </select>

                    <label><strong>Select Images (you can select multiple):</strong></label>
                    <input type="file" name="files" accept="image/*" multiple required>

                    <input type="submit" value="Upload Images">
                </form>
                <div style="margin-top: 20px; text-align: center;">
                    <a href="/fields" style="color: #2196f3;">← Back to Fields</a>
                </div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)

    @app.post("/fields/{field_id}/upload-zone-images", response_class=HTMLResponse)
    async def upload_zone_images(
        field_id: int,
        zone_number: int = Form(...),
        files: List[UploadFile] = File(...),
        db: Session = Depends(get_db)
    ):
        """Upload multiple images for a specific zone"""
        try:
            uploaded_files = []

            for file in files:
                if not file.content_type.startswith('image/'):
                    continue

                content = await file.read()
                field_image = field_service.save_field_image(
                    db=db,
                    field_id=field_id,
                    zone_number=zone_number,
                    file_content=content,
                    original_filename=file.filename
                )
                uploaded_files.append(field_image.id)

            stats = field_service.get_field_statistics(db, field_id)

            html_content = f"""
            <html>
            <head>
                <title>Upload Success</title>
                <meta http-equiv="refresh" content="2;url=/fields/{field_id}/upload-form" />
                <style>
                    body {{
                        font-family: Arial, sans-serif;
                        text-align: center;
                        padding: 50px;
                        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    }}
                    .success {{
                        background: white;
                        padding: 30px;
                        border-radius: 10px;
                        display: inline-block;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                    }}
                </style>
            </head>
            <body>
                <div class="success">
                    <h1>✅ Upload Successful!</h1>
                    <p>Uploaded {len(uploaded_files)} images to Zone {zone_number}</p>
                    <p>Total Progress: {stats['total_images']}/450 images ({stats['completion_percentage']:.1f}%)</p>
                    <p>Redirecting back...</p>
                </div>
            </body>
            </html>
            """
            return HTMLResponse(content=html_content)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))

    @app.get("/fields/{field_id}/process-form", response_class=HTMLResponse)
    async def process_form(field_id: int, db: Session = Depends(get_db)):
        """Form to process field"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise HTTPException(status_code=404, detail="Field not found")

        html_content = f"""
        <html>
        <head>
            <title>Process Field - {field.name}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    padding: 20px;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                }}
                .container {{
                    max-width: 600px;
                    margin: 50px auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                    text-align: center;
                }}
                h1 {{
                    color: #2e7d32;
                }}
                form {{
                    margin-top: 30px;
                }}
                input[type="submit"] {{
                    background: #ff9800;
                    color: white;
                    border: none;
                    padding: 15px 30px;
                    font-size: 1.1em;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                }}
                input[type="submit"]:hover {{
                    background: #f57c00;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Process Field: {field.name}</h1>
                <p>This will process all uploaded images using the YOLO model and generate comprehensive analytics.</p>
                <p><strong>Warning:</strong> This may take several minutes depending on the number of images.</p>
                <form action="/fields/{field_id}/process" method="post">
                    <input type="submit" value="Start Processing">
                </form>
                <div style="margin-top: 20px;">
                    <a href="/fields" style="color: #2196f3;">← Back to Fields</a>
                </div>
            </div>
        </body>
        </html>
        """
        return HTMLResponse(content=html_content)

    @app.post("/fields/{field_id}/process", response_class=HTMLResponse)
    async def process_field(
        field_id: int,
        db: Session = Depends(get_db)
    ):
        """Process all images for a field and generate analysis"""
        try:
            # Get field
            field = db.query(Field).filter(Field.id == field_id).first()
            if not field:
                raise HTTPException(status_code=404, detail="Field not found")

            # Process all images
            analysis = batch_service.process_field_images(
                db=db,
                field_id=field_id,
                confidence_threshold=0.25
            )

            # Generate visualizations
            field_data = {
                "id": field.id,
                "name": field.name,
                "location_name": field.location_name,
                "size_hectares": field.size_hectares
            }

            analysis_data = {
                "total_images_processed": analysis.total_images_processed,
                "total_weeds_detected": analysis.total_weeds_detected,
                "total_crops_detected": analysis.total_crops_detected,
                "overall_infestation_percentage": analysis.overall_infestation_percentage,
                "zone_statistics": analysis.zone_statistics,
                "weed_species_distribution": analysis.weed_species_distribution,
                "hotspot_zones": analysis.hotspot_zones,
                "treatment_priority": analysis.treatment_priority,
                "analysis_date": analysis.analysis_date.strftime("%Y-%m-%d %H:%M:%S")
            }

            # Create visualization
            viz_path = viz_service.create_field_visualization(
                field_data=field_data,
                analysis_data=analysis_data,
                satellite_image_path=analysis.satellite_image_path
            )

            # Create HTML dashboard
            dashboard_path = viz_service.generate_html_dashboard(
                field_data=field_data,
                analysis_data=analysis_data,
                visualization_path=viz_path
            )

            # Update analysis with paths
            analysis.visualization_image_path = viz_path
            db.commit()

            # Return HTML dashboard
            with open(dashboard_path, 'r', encoding='utf-8') as f:
                html_content = f.read()

            return HTMLResponse(content=html_content)

        except Exception as e:
            logger.error(f"Error processing field: {e}")
            raise HTTPException(status_code=500, detail=str(e))

    def _generate_enhanced_dashboard(field: Field, analysis: FieldAnalysis, db: Session) -> str:
        """Generate enhanced hierarchical dashboard with proper zone order and block/image views"""

        # Get all images for the field
        images = db.query(FieldImage).filter(FieldImage.field_id == field.id).all()
        images_by_zone_block = {}
        for img in images:
            key = (img.zone_number, img.block_number)
            if key not in images_by_zone_block:
                images_by_zone_block[key] = []
            images_by_zone_block[key].append(img)

        # Sort zone statistics properly (1-9, top to bottom, left to right)
        zone_stats = sorted(analysis.zone_statistics, key=lambda x: x['zone'])
        block_stats = sorted(analysis.block_statistics, key=lambda x: (x['zone'], x['block']))

        # Generate zone grid HTML (proper order: 1,2,3 / 4,5,6 / 7,8,9)
        zones_html = ""
        for row in [1, 2, 3]:  # Top, Middle, Bottom
            zones_html += '<div class="zone-row">'
            for col in [1, 2, 3]:  # Left, Center, Right
                zone_num = (row - 1) * 3 + col
                zone_stat = next((z for z in zone_stats if z['zone'] == zone_num), None)

                if zone_stat:
                    # Get blocks for this zone
                    zone_blocks = [b for b in block_stats if b['zone'] == zone_num]
                    zone_blocks_html = ""

                    # Generate 3x3 block grid for this zone
                    for block_row in [1, 2, 3]:
                        zone_blocks_html += '<div class="block-row">'
                        for block_col in [1, 2, 3]:
                            block_num = (block_row - 1) * 3 + block_col
                            block_stat = next((b for b in zone_blocks if b['block'] == block_num), None)

                            if block_stat:
                                # Get images for this block
                                block_images = images_by_zone_block.get((zone_num, block_num), [])
                                block_color = 'green' if block_stat['infestation_level'] == 'low' else 'orange' if block_stat['infestation_level'] == 'medium' else 'red'

                                # Generate 2x2 image thumbnail grid
                                images_html = '<div class="images-grid">'
                                for i, img in enumerate(block_images[:4]):  # Show up to 4 images
                                    images_html += f'<img src="/image/{img.id}" class="thumb" title="{img.original_filename}">'
                                images_html += '</div>'

                                zone_blocks_html += f'''
                                <div class="block" style="border-color: {block_color};" title="Block {block_num}">
                                    <div class="block-num">B{block_num}</div>
                                    <div class="block-weeds">{block_stat['weeds']}w</div>
                                    {images_html}
                                </div>
                                '''
                        zone_blocks_html += '</div>'

                    zones_html += f'''
                    <div class="zone">
                        <div class="zone-header">
                            <strong>Zone {zone_num}</strong><br>
                            {zone_stat['zone_name']}<br>
                            <span class="weed-count">{zone_stat['weeds_detected']} weeds</span>
                        </div>
                        <div class="blocks-container">
                            {zone_blocks_html}
                        </div>
                    </div>
                    '''
            zones_html += '</div>'

        # Generate complete dashboard
        html = f'''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Field Analysis - {field.name}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    margin: 20px;
                    background: #f5f5f5;
                }}
                .container {{
                    max-width: 1400px;
                    margin: 0 auto;
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }}
                h1 {{
                    color: #2e7d32;
                    text-align: center;
                }}
                .summary {{
                    background: #e8f5e9;
                    padding: 20px;
                    border-radius: 8px;
                    margin: 20px 0;
                    display: flex;
                    justify-content: space-around;
                    flex-wrap: wrap;
                }}
                .summary-item {{
                    text-align: center;
                    padding: 10px 20px;
                }}
                .summary-item .number {{
                    font-size: 2em;
                    font-weight: bold;
                    color: #2e7d32;
                }}
                .zone-row {{
                    display: flex;
                    gap: 15px;
                    margin-bottom: 15px;
                    justify-content: center;
                }}
                .zone {{
                    border: 3px solid #4caf50;
                    border-radius: 8px;
                    padding: 15px;
                    background: white;
                    flex: 1;
                    max-width: 400px;
                }}
                .zone-header {{
                    text-align: center;
                    margin-bottom: 10px;
                    padding-bottom: 10px;
                    border-bottom: 2px solid #e0e0e0;
                }}
                .weed-count {{
                    color: #d32f2f;
                    font-weight: bold;
                    font-size: 1.1em;
                }}
                .blocks-container {{
                    margin-top: 10px;
                }}
                .block-row {{
                    display: flex;
                    gap: 5px;
                    margin-bottom: 5px;
                }}
                .block {{
                    border: 2px solid #888;
                    border-radius: 4px;
                    padding: 5px;
                    flex: 1;
                    text-align: center;
                    background: #fafafa;
                    min-height: 100px;
                }}
                .block-num {{
                    font-weight: bold;
                    font-size: 0.8em;
                    color: #666;
                }}
                .block-weeds {{
                    font-size: 0.9em;
                    color: #d32f2f;
                    margin: 3px 0;
                }}
                .images-grid {{
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 2px;
                    margin-top: 5px;
                }}
                .thumb {{
                    width: 100%;
                    height: 40px;
                    object-fit: cover;
                    border-radius: 2px;
                }}
                .back-link {{
                    display: inline-block;
                    margin-bottom: 20px;
                    color: #2196f3;
                    text-decoration: none;
                    font-weight: bold;
                }}
                .legend {{
                    margin: 20px 0;
                    padding: 15px;
                    background: #f9f9f9;
                    border-radius: 5px;
                }}
                .legend-item {{
                    display: inline-block;
                    margin-right: 20px;
                }}
                .legend-box {{
                    display: inline-block;
                    width: 20px;
                    height: 20px;
                    border: 2px solid;
                    vertical-align: middle;
                    margin-right: 5px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <a href="/fields" class="back-link">← Back to Fields</a>
                <h1>🌾 Field Analysis: {field.name}</h1>

                <div class="summary">
                    <div class="summary-item">
                        <div class="number">{analysis.total_images_processed}</div>
                        <div>Images Processed</div>
                    </div>
                    <div class="summary-item">
                        <div class="number">{analysis.total_weeds_detected}</div>
                        <div>Total Weeds</div>
                    </div>
                    <div class="summary-item">
                        <div class="number">{analysis.total_crops_detected}</div>
                        <div>Total Crops</div>
                    </div>
                    <div class="summary-item">
                        <div class="number">{getattr(analysis, 'overall_infestation_percentage', 0):.1f}%</div>
                        <div>Infestation Rate (Area-Based)</div>
                    </div>
                </div>

                <div class="legend">
                    <strong>Legend:</strong>
                    <div class="legend-item">
                        <span class="legend-box" style="border-color: green;"></span> Low Infestation
                    </div>
                    <div class="legend-item">
                        <span class="legend-box" style="border-color: orange;"></span> Medium Infestation
                    </div>
                    <div class="legend-item">
                        <span class="legend-box" style="border-color: red;"></span> High Infestation
                    </div>
                </div>

                <h2 style="text-align: center; color: #666;">Field Grid View (Zone → Block → Images)</h2>

                {zones_html}

                <div style="text-align: center; margin-top: 30px; color: #888;">
                    <p>Analysis Date: {analysis.analysis_date.strftime("%Y-%m-%d %H:%M:%S")}</p>
                </div>
            </div>
        </body>
        </html>
        '''
        return html

    def _generate_combined_dashboard(field_data: Dict, analysis_data: Dict,
                                     viz_base64: str, zone_grid_html: str) -> str:
        """Generate combined dashboard with visualizations AND zone/block/image grid"""

        # Extract zone HTML and styles
        import re

        # Extract the zones_html content (zone-row divs)
        # Pattern: Find content between the heading and the analysis date footer
        match = re.search(r'Field Grid View.*?</h2>\s*(.*?)<div style="text-align: center; margin-top:',
                         zone_grid_html, re.DOTALL)

        zones_section = match.group(1).strip() if match else ""

        # Extract styles from zone_grid_html
        style_match = re.search(r'<style>(.*?)</style>', zone_grid_html, re.DOTALL)
        zone_styles = style_match.group(1) if style_match else ""

        # Calculate summary statistics
        total_images = analysis_data['total_images_processed']
        total_weeds = analysis_data['total_weeds_detected']
        total_crops = analysis_data['total_crops_detected']

        # Use area-based overall infestation percentage if available
        weed_percentage = analysis_data.get('overall_infestation_percentage', 0)

        hotspot_zones = analysis_data.get('hotspot_zones', [])
        treatment_priority = analysis_data.get('treatment_priority', [])

        # Generate combined HTML
        html_content = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Field Analysis Dashboard - {field_data['name']}</title>
            <style>
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}
                body {{
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 20px;
                    color: #333;
                }}
                .container {{
                    max-width: 1600px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
                    overflow: hidden;
                }}
                .header {{
                    background: linear-gradient(135deg, #2e7d32 0%, #4caf50 100%);
                    color: white;
                    padding: 30px;
                    text-align: center;
                }}
                .header h1 {{
                    font-size: 2.5em;
                    margin-bottom: 10px;
                }}
                .header p {{
                    font-size: 1.2em;
                    opacity: 0.9;
                }}
                .stats-grid {{
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                    gap: 20px;
                    padding: 30px;
                    background: #f5f5f5;
                }}
                .stat-card {{
                    background: white;
                    padding: 25px;
                    border-radius: 10px;
                    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                    text-align: center;
                    transition: transform 0.3s;
                }}
                .stat-card:hover {{
                    transform: translateY(-5px);
                    box-shadow: 0 8px 12px rgba(0,0,0,0.15);
                }}
                .stat-card .value {{
                    font-size: 3em;
                    font-weight: bold;
                    color: #2e7d32;
                    margin: 10px 0;
                }}
                .stat-card .label {{
                    font-size: 1.1em;
                    color: #666;
                    text-transform: uppercase;
                    letter-spacing: 1px;
                }}
                .visualization {{
                    padding: 30px;
                }}
                .visualization img {{
                    width: 100%;
                    border-radius: 10px;
                    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                }}
                .visualization h2 {{
                    color: #2e7d32;
                    margin-bottom: 20px;
                    text-align: center;
                }}

                /* Zone grid styles from enhanced dashboard */
                {zone_styles}

                .zone-section {{
                    padding: 30px;
                    background: #f9f9f9;
                }}
                .zone-section h2 {{
                    color: #2e7d32;
                    margin-bottom: 20px;
                    text-align: center;
                    font-size: 1.8em;
                }}
                .recommendations {{
                    padding: 30px;
                    background: #fff3cd;
                }}
                .recommendations h2 {{
                    color: #856404;
                    margin-bottom: 20px;
                }}
                .recommendation-item {{
                    background: white;
                    padding: 15px;
                    margin-bottom: 15px;
                    border-left: 4px solid #ffc107;
                    border-radius: 5px;
                }}
                .recommendation-item h3 {{
                    color: #2e7d32;
                    margin-bottom: 10px;
                }}
                .hotspot-badge {{
                    display: inline-block;
                    background: #d32f2f;
                    color: white;
                    padding: 5px 10px;
                    border-radius: 20px;
                    font-size: 0.9em;
                    margin: 5px;
                }}
                .footer {{
                    text-align: center;
                    padding: 20px;
                    background: #f5f5f5;
                    color: #666;
                }}
                .button {{
                    display: inline-block;
                    background: #4caf50;
                    color: white;
                    padding: 12px 30px;
                    border-radius: 25px;
                    text-decoration: none;
                    margin: 20px;
                    font-weight: bold;
                    transition: background 0.3s;
                }}
                .button:hover {{
                    background: #388e3c;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🌾 Field Analysis Dashboard</h1>
                    <p>{field_data['name']} | {field_data.get('location_name', 'Kazakhstan')}</p>
                    <p style="font-size: 0.9em; margin-top: 10px;">
                        {field_data['size_hectares']} hectares | Analysis Date: {analysis_data.get('analysis_date', 'Today')}
                    </p>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="label">Images Processed</div>
                        <div class="value">{total_images}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Total Weeds</div>
                        <div class="value" style="color: #d32f2f;">{total_weeds}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Total Crops</div>
                        <div class="value" style="color: #388e3c;">{total_crops}</div>
                    </div>
                    <div class="stat-card">
                        <div class="label">Weed Infestation (Area-Based)</div>
                        <div class="value" style="color: #f57c00;">{weed_percentage:.1f}%</div>
                    </div>
                </div>

                <div class="visualization">
                    <h2>📊 Field Visualization & Analytics</h2>
                    <img src="data:image/png;base64,{viz_base64}" alt="Field Analysis Visualization">
                </div>

                <div class="zone-section">
                    <h2>🗺️ Detailed Zone & Block Analysis</h2>
                    <p style="text-align: center; margin-bottom: 20px; color: #666;">
                        Click on any image to view full size with weed detections
                    </p>
                    <div class="zones-container">
                        {zones_section}
                    </div>
                </div>

                <div class="recommendations">
                    <h2>⚠️ Treatment Recommendations</h2>

                    <div class="recommendation-item">
                        <h3>🎯 Priority Zones (Hotspots)</h3>
                        <p>The following zones require immediate attention:</p>
                        <div>
                            {''.join([f'<span class="hotspot-badge">Zone {{z}}</span>' for z in hotspot_zones]) if hotspot_zones else '<p>No critical hotspots detected</p>'}
                        </div>
                    </div>

                    {''.join([f'''
                    <div class="recommendation-item">
                        <h3>Priority {rec['priority']}: {rec['action']}</h3>
                        <p>{rec['description']}</p>
                    </div>
                    ''' for rec in treatment_priority])}
                </div>

                <div class="footer">
                    <a href="/fields" class="button">← Back to Fields</a>
                    <a href="/" class="button">🏠 Home</a>
                    <p style="margin-top: 20px;">
                        Powered by YOLOv8 Deep Learning Model | Weed Detection System v2.0
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        return html_content

    @app.get("/fields/{field_id}/view-analysis", response_class=HTMLResponse)
    async def view_analysis(field_id: int, db: Session = Depends(get_db)):
        """View the most recent analysis for a field with both visualizations and image grid"""
        field = db.query(Field).filter(Field.id == field_id).first()
        if not field:
            raise HTTPException(status_code=404, detail="Field not found")

        analysis = db.query(FieldAnalysis).filter(
            FieldAnalysis.field_id == field_id
        ).order_by(FieldAnalysis.analysis_date.desc()).first()

        if not analysis:
            raise HTTPException(status_code=404, detail="No analysis found for this field")

        field_data = {
            "id": field.id,
            "name": field.name,
            "location_name": field.location_name,
            "size_hectares": field.size_hectares
        }

        analysis_data = {
            "total_images_processed": analysis.total_images_processed,
            "total_weeds_detected": analysis.total_weeds_detected,
            "total_crops_detected": analysis.total_crops_detected,
            "overall_infestation_percentage": getattr(analysis, 'overall_infestation_percentage', 0),
            "zone_statistics": analysis.zone_statistics,
            "weed_species_distribution": analysis.weed_species_distribution,
            "hotspot_zones": analysis.hotspot_zones,
            "treatment_priority": analysis.treatment_priority,
            "analysis_date": analysis.analysis_date.strftime("%Y-%m-%d %H:%M:%S")
        }

        # Generate visualization if it doesn't exist
        viz_path = viz_service.create_field_visualization(
            field_data=field_data,
            analysis_data=analysis_data,
            satellite_image_path=getattr(analysis, 'satellite_image_path', None)
        )

        # Convert visualization to base64
        import base64
        with open(viz_path, 'rb') as img_file:
            viz_base64 = base64.b64encode(img_file.read()).decode()

        # Generate the hierarchical zone/block/image grid HTML
        zone_grid_html = _generate_enhanced_dashboard(field, analysis, db)

        # Combine both: Extract just the zone grid section from the enhanced dashboard
        # and merge with visualization dashboard
        html_content = _generate_combined_dashboard(
            field_data, analysis_data, viz_base64, zone_grid_html
        )

        return HTMLResponse(content=html_content)

    @app.get("/image/{image_id}")
    async def serve_image(image_id: int, db: Session = Depends(get_db)):
        """Serve annotated field image by ID (with YOLO detections drawn) - with caching"""
        from fastapi.responses import FileResponse, Response
        import hashlib

        image = db.query(FieldImage).filter(FieldImage.id == image_id).first()
        if not image or not os.path.exists(image.image_path):
            raise HTTPException(status_code=404, detail="Image not found")

        # Get detection results for this image
        detection = db.query(DetectionResult).filter(
            DetectionResult.field_image_id == image_id
        ).first()

        if detection and detection.detection_data:
            # Check if cached annotated image exists
            cache_dir = "visualizations/annotated_cache"
            os.makedirs(cache_dir, exist_ok=True)
            cache_path = os.path.join(cache_dir, f"annotated_{image_id}.jpg")

            # Return cached if exists
            if os.path.exists(cache_path):
                return FileResponse(
                    cache_path,
                    media_type="image/jpeg",
                    headers={"Cache-Control": "public, max-age=31536000"}  # Cache for 1 year
                )

            # Generate and cache annotated image
            annotated_image = _draw_detections_on_image(
                image.image_path,
                detection.detection_data
            )

            # Save to cache
            from PIL import Image as PILImage
            PILImage.fromarray(cv2.cvtColor(annotated_image, cv2.COLOR_BGR2RGB)).save(
                cache_path, 'JPEG', quality=85, optimize=True
            )

            return FileResponse(
                cache_path,
                media_type="image/jpeg",
                headers={"Cache-Control": "public, max-age=31536000"}
            )
        else:
            # No detection data, return original image with cache headers
            return FileResponse(
                image.image_path,
                media_type="image/jpeg",
                headers={"Cache-Control": "public, max-age=31536000"}
            )

    def _draw_detections_on_image(image_path: str, predictions: list) -> np.ndarray:
        """Draw YOLO detection boxes on image"""
        img = cv2.imread(image_path)
        if img is None:
            return np.zeros((100, 100, 3), dtype=np.uint8)

        # Colors for different classes
        colors = {
            'weed': (0, 0, 255),    # Red for weeds
            'crop': (0, 255, 0)      # Green for crops
        }

        for pred in predictions:
            bbox = pred.get('bbox', [])
            if len(bbox) == 4:
                x1, y1, x2, y2 = map(int, bbox)
                weed_type = pred.get('weed_type', 'unknown')
                color = colors.get(weed_type, (255, 255, 0))

                # Draw box
                cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)

                # Draw label
                label = f"{pred.get('class_name', 'unknown')} {pred.get('confidence', 0):.2f}"
                cv2.putText(img, label, (x1, y1-5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        return img

if __name__ == "__main__":
    import uvicorn
    print("Starting Weed Classification API...")
    print("Access at: http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")